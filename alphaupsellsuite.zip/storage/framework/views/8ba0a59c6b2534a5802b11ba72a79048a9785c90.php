<!-----------Modal-4---------->
<div class="modal fade" id="centralModalSm4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
   aria-hidden="true">
   <!-- Change class .modal-sm to change the size of the modal -->
   <form class="template-<?php echo e($upsellTemplateId); ?>">
      <div class="modal-dialog modal-sm m_1_w" role="document">
         <div class="modal-content modal_1_show" style="height: 100vh;">
            <div class="modal-header">
               <h4 class="modal-title w-100 m_head_h">Customize Your Template</h4>
               <button type="button" class="close m1_close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body m_1_body">
               <div class="container">
                  <div class="col-md-12 popup_page">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="design_input">
                              <h3>Countdown For Sales Timer</h3>
                              <div class="custom-control custom-checkbox">
                                 <input type="checkbox" value="1" class="custom-control-input" id="alpha_t4_time_limit_toggler" name="alpha_t4_time_limit_toggler" 
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          <?php echo e($upsell->setting['alpha_t4_time_limit_toggler'] ? "checked" : ""); ?>

                                       <?php else: ?>    
                                          <?php echo e($setting['offer_time_limit'] ? "checked":""); ?>

                                       <?php endif; ?>
                                    <?php else: ?>
                                       <?php echo e($setting['offer_time_limit'] ? "checked":""); ?>

                                    <?php endif; ?>
                                 />
                                 <label class="custom-control-label" for="alpha_t4_time_limit_toggler">Add a Time Limit To The Offer</label>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Timer Duration In Minutes</label><br>
                                       <input type="number" name="alpha_t4_time_duration" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_time_duration']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['time_duration_minutes']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_duration_minutes']); ?>"
                                          <?php endif; ?>
                                       />    
                                    </p>
                                    <p class="f_input">
                                       <label>Timer Text</label><br>
                                       <input type="text"  placeholder="Deal Ends Soon:" name="alpha_t4_timer_heading" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_timer_heading']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['time_offer_heading']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_offer_heading']); ?>"
                                          <?php endif; ?>
                                       />    	  
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Font Family</label><br>
                                       <select name="alpha_t4_timer_heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>" 
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['alpha_t4_timer_heading_font_family']  == $family ? "selected":""); ?>   
                                                   <?php else: ?>    
                                                      <?php echo e($setting['time_offer_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($setting['time_offer_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?>
                                             >
                                                <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Font Size</label><br>
                                       <input type="number" name="alpha_t4_timer_heading_font_size" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_timer_heading_font_size']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['time_offer_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['time_offer_font_size']); ?>"
                                          <?php endif; ?>
                                       />
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t4_timer_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t4_timer_heading_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t4_timer_heading_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_timer_heading_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_heading_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Heading Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t4_timer_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t4_timer_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t4_timer_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_timer_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t4_timer_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t4_timer_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t4_timer_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_timer_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t4_cross_icon_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t4_cross_icon_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cross_icon_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t4_cross_icon_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_cross_icon_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cross_icon_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Icon Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t4_cross_icon_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t4_cross_icon_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cross_icon_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t4_cross_icon_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_cross_icon_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cross_icon_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_bg_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['cross_icon_bg_color']); ?>" />
                                       <p>Icon Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Cart Product</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t4_cart_product_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t4_cart_product_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_product_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_product_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t4_cart_product_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_cart_product_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_product_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_product_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t4_cart_product_icon_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t4_cart_product_icon_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_cross_icon_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_cross_icon_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t4_cart_product_icon_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t4_cart_product_icon_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_cross_icon_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_cross_icon_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Icon Background Color</p>
                                       </form>
                                    </div>
                                 </div>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_cart_product_price_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_cart_product_price_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['cart_product_price_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['cart_product_price_color']); ?>;" 
                                             <?php endif; ?>
                                          ></a>
                                          <input type="hidden" name="alpha_t4_cart_product_price_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_cart_product_price_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['cart_product_price_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['cart_product_price_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Price Color </p>
                                       </div>
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_cart_product_checkout_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_cart_product_checkout_btn_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['cart_product_checkout_text_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['cart_product_checkout_text_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_cart_product_checkout_btn_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_cart_product_checkout_btn_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['cart_product_checkout_text_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['cart_product_checkout_text_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Checkout Button Color </p>
                                       </div>
                                    </div>
                                 </div>
                                 <h3>Title</h3>
                                 <p class="h_input">
                                    <label>Heading</label><br>
                                    <input type="text" placeholder="Check out these items we think you would love!" name="alpha_t4_title_heading" value=
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             "<?php echo e($upsell->setting['alpha_t4_title_heading']); ?>"    
                                          <?php else: ?>    
                                             "<?php echo e($setting['offer_heading']); ?>"
                                          <?php endif; ?>
                                       <?php else: ?>
                                          "<?php echo e($setting['offer_heading']); ?>" 
                                       <?php endif; ?>
                                    />    
                                 </p>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <p class="f_input">
                                          <label>Font Family</label><br>
                                          <select name="alpha_t4_title_heading_font_family">
                                             <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($family); ?>" 
                                                   <?php if(isset($upsell)): ?>
                                                      <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                         <?php echo e($upsell->setting['alpha_t4_title_heading_font_family']  == $family ? "selected":""); ?>   
                                                      <?php else: ?>    
                                                         <?php echo e($setting['offer_heading_font_family'] == $family ? "selected":""); ?>

                                                      <?php endif; ?>
                                                   <?php else: ?>
                                                      <?php echo e($setting['offer_heading_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                >
                                                   <?php echo e($family); ?>

                                                </option>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                       </p>
                                       <p class="f_input">
                                          <label>Font Size</label><br>
                                          <input type="number" name="alpha_t4_title_heading_font_size" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_title_heading_font_size']); ?>"   
                                                <?php else: ?>    
                                                   "<?php echo e($setting['offer_heading_font_size']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['offer_heading_font_size']); ?>"
                                             <?php endif; ?>
                                          >    
                                       </p>
                                    </div>
                                 </div>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_title_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_title_heading_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['offer_heading_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['offer_heading_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_title_heading_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_title_heading_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['offer_heading_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['offer_heading_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Heading Color </p>
                                       </div>
                                    </div>
                                 </div>
                                 <h3>Product</h3>
                                 <p class="h_input">
                                    <label>Button Text</label><br>
                                    <input type="text" name="alpha_t4_atc_btn"  value=
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             "<?php echo e($upsell->setting['alpha_t4_atc_btn']); ?>"    
                                          <?php else: ?>    
                                             "<?php echo e($setting['add_to_cart_text']); ?>"
                                          <?php endif; ?>
                                       <?php else: ?>
                                          "<?php echo e($setting['add_to_cart_text']); ?>" 
                                       <?php endif; ?>
                                    />    
                                 </p>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_atc_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_atc_btn_bg_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['atc_background_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['atc_background_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_atc_btn_bg_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_atc_btn_bg_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['atc_background_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['atc_background_color']); ?>" 
                                             <?php endif; ?>
                                          "<?php echo e($setting['atc_background_color']); ?>" />
                                          <p>Button Background Color</p>
                                       </div>
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_atc_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_atc_btn_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['atc_text_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['atc_text_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_atc_btn_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_atc_btn_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['atc_text_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['atc_text_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Button Text Color</p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_price_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_price_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['Original_price_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['Original_price_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_price_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_price_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['Original_price_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['Original_price_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Original Price Color </p>
                                       </div>
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_discount_price_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_discount_price_bg_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['discount_background_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['discount_background_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_discount_price_bg_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_discount_price_bg_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['discount_background_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['discount_background_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Discount Background Color </p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_discount_price_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_discount_price_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['discount_text_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['discount_text_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_discount_price_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_discount_price_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['discount_text_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['discount_text_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Discount Text Color</p>
                                       </div>
                                    </div>
                                 </div>
                                 <h3 class="mt-4">Translation</h3>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <p class="f_input">
                                          <label>Checkout Button</label><br>
                                          <input type="text" placeholder="Checkout" name="alpha_t4_checkout_btn" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_checkout_btn']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['checkout_button_text']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['checkout_button_text']); ?>" 
                                             <?php endif; ?>
                                          />    
                                       </p>
                                       <p class="f_input">
                                          <label>No Thanks Button</label><br>
                                          <input type="text" placeholder="No Thanks" name="alpha_t4_no_thanks_btn" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_no_thanks_btn']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['no_thanks_button_text']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['no_thanks_button_text']); ?>" 
                                             <?php endif; ?>
                                          />    	  
                                       </p>
                                    </div>
                                 </div>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_checkout_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_checkout_btn_bg_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['checkout_background_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['checkout_background_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_checkout_btn_bg_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_checkout_btn_bg_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['checkout_background_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['checkout_background_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Checkout Background Color </p>
                                       </div>
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_no_thanks_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_no_thanks_btn_bg_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_no_thanks_btn_bg_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_no_thanks_btn_bg_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['no_thanks_background_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['no_thanks_background_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>No,Thanks Background Color </p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_checkout_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_checkout_btn_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['checkout_text_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['checkout_text_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_checkout_btn_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_checkout_btn_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['checkout_text_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['checkout_text_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Checkout Text Color </p>
                                       </div>
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_no_thanks_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_no_thanks_btn_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_no_thanks_btn_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_no_thanks_btn_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['no_thanks_text_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['no_thanks_text_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>No,Thanks Text Color </p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-md-12 font">
                                    <div class="row">
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_checkout_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_checkout_btn_border_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['checkout_border_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['checkout_border_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_checkout_btn_border_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_checkout_btn_border_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['checkout_border_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['checkout_border_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>Checkout Border Color </p>
                                       </div>
                                       <div class="f_input_color">
                                          <a href="#" data-id="alpha_t4_no_thanks_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "background-color:<?php echo e($upsell->setting['alpha_t4_no_thanks_btn_border_color']); ?>;"    
                                                <?php else: ?>    
                                                   "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;" 
                                             <?php endif; ?>
                                          >
                                          </a>
                                          <input type="hidden" name="alpha_t4_no_thanks_btn_border_color" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t4_no_thanks_btn_border_color']); ?>"    
                                                <?php else: ?>    
                                                   "<?php echo e($setting['no_thanks_border_color']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['no_thanks_border_color']); ?>" 
                                             <?php endif; ?>
                                          />
                                          <p>No,Thanks Border Color </p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="design_p_inpage pt-2">
                              <!-------Modal content------->
                              <div class="modal-content modal_4 alpha_atc_t_4">
                                 <div class="modal_4_head">
                                    <div>
                                       <span class="close alpha_t4_cross_icon" id="myModal4">×</span>
                                       <div class="b_timer4">
                                          <h4 class="b_timer4_heading">
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   <?php echo e($upsell->setting['alpha_t4_timer_heading']); ?>   
                                                <?php else: ?>    
                                                <?php echo e($setting['time_offer_heading']); ?>

                                                <?php endif; ?>
                                             <?php else: ?>
                                             <?php echo e($setting['time_offer_heading']); ?>

                                             <?php endif; ?>
                                          </h4>
                                          <div class="timer4">
                                             <input type="text" class="alpha_t4_timer t4_timer" readonly value=
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      "<?php echo e($upsell->setting['alpha_t4_time_duration']); ?>"   
                                                   <?php else: ?>    
                                                   "<?php echo e($setting['time_duration_minutes']); ?>"
                                                   <?php endif; ?>
                                                <?php else: ?>
                                                "<?php echo e($setting['time_duration_minutes']); ?>"
                                                <?php endif; ?>
                                              ><input type="text" class="t4_timer" value="00" readonly>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="m4_top alpha_t4_cart_product" >
                                    <div style="display: flex; justify-content: space-between;">
                                       <span class="m4_t1"><i class="alpha_t4_p_t4_cross" style="background: #4A4A4A;"> &#10004;</i> Nivea Skin Firming And Toning Gel Cream...</span>
                                       <!-- <span class="m4_t2"><input type="number" min="1" value="2"></span> -->
                                       <span class="m4_t3 t4_Cart_product_price" style="font-weight: bold !important;"><?php echo e($currency); ?>19.99</span>
                                       <!-- <span class="m4_t4 t4_checkout">Checkout</span> -->
                                    </div>
                                 </div>
                                 <div class="m4_body">
                                    <h2 class="t4_heading">
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             <?php echo e($upsell->setting['alpha_t4_title_heading']); ?>    
                                          <?php else: ?>    
                                             <?php echo e($setting['offer_heading']); ?>

                                          <?php endif; ?>
                                       <?php else: ?>
                                          <?php echo e($setting['offer_heading']); ?> 
                                       <?php endif; ?>                                       
                                    </h2>
                                    <div class="m4_product_main">
                                       <div class="m4_detail">
                                          <div class="m4_p">
                                             <div class="m_4_img">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-5-1.jpg" alt="shoes">
                                             </div>
                                             <div class="m_4_img_detail">
                                                <h4>Discord Sunglasses</h4>
                                                <p><?php echo e($currency); ?>39.95 <span>30%Off</span></p>
                                                <select>
                                                   <option>Black</option>
                                                   <option>Blue</option>
                                                   <option>Red</option>
                                                </select>
                                                <input type="button" class="t4_atc_btn" value=
                                                   <?php if(isset($upsell)): ?>
                                                      <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                         "<?php echo e($upsell->setting['alpha_t4_atc_btn']); ?>"    
                                                      <?php else: ?>    
                                                         "<?php echo e($setting['add_to_cart_text']); ?>"
                                                      <?php endif; ?>
                                                   <?php else: ?>
                                                      "<?php echo e($setting['add_to_cart_text']); ?>" 
                                                   <?php endif; ?>
                                                >
                                             </div>
                                          </div>
                                       </div>
                                       <div class="m4_detail">
                                          <div class="m4_p">
                                             <div class="m_4_img">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-5-2.jpg" alt="shoes">
                                             </div>
                                             <div class="m_4_img_detail">
                                                <h4>High Heels Shoes</h4>
                                                <p><?php echo e($currency); ?>79.95 <span>30%Off</span></p>
                                                <select class="img_select">
                                                   <option>Black</option>
                                                   <option>Blue</option>
                                                   <option>Red</option>
                                                </select>
                                                <select class="img_select">
                                                   <option>22</option>
                                                   <option>24</option>
                                                   <option>26</option>
                                                </select>
                                                <input type="button" class="t4_atc_btn" value=
                                                   <?php if(isset($upsell)): ?>
                                                      <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                         "<?php echo e($upsell->setting['alpha_t4_atc_btn']); ?>"    
                                                      <?php else: ?>    
                                                         "<?php echo e($setting['add_to_cart_text']); ?>"
                                                      <?php endif; ?>
                                                   <?php else: ?>
                                                      "<?php echo e($setting['add_to_cart_text']); ?>" 
                                                   <?php endif; ?>
                                                >
                                             </div>
                                          </div>
                                       </div>
                                       <div class="m4_detail">
                                          <div class="m4_p">
                                             <div class="m_4_img">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-5-3.jpg" alt="shoes">
                                             </div>
                                             <div class="m_4_img_detail">
                                                <h4>Leather Shoulder Bag</h4>
                                                <p><?php echo e($currency); ?>54.95 <span>30%Off</span></p>
                                                <select>
                                                   <option>Black</option>
                                                   <option>Blue</option>
                                                   <option>Red</option>
                                                </select>
                                                <input type="button" class="t4_atc_btn" value=
                                                   <?php if(isset($upsell)): ?>
                                                      <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                         "<?php echo e($upsell->setting['alpha_t4_atc_btn']); ?>"    
                                                      <?php else: ?>    
                                                         "<?php echo e($setting['add_to_cart_text']); ?>"
                                                      <?php endif; ?>
                                                   <?php else: ?>
                                                      "<?php echo e($setting['add_to_cart_text']); ?>" 
                                                   <?php endif; ?>
                                                >
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="m4_footer">
                                    <input type="button" class="m4_check t4_checkout" value=
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             "<?php echo e($upsell->setting['alpha_t4_checkout_btn']); ?>"    
                                          <?php else: ?>    
                                             "<?php echo e($setting['checkout_button_text']); ?>"
                                          <?php endif; ?>
                                       <?php else: ?>
                                          "<?php echo e($setting['checkout_button_text']); ?>" 
                                       <?php endif; ?>
                                     >
                                    <input type="button" class="m4_thanks t4_thanks" value=
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             "<?php echo e($upsell->setting['alpha_t4_no_thanks_btn']); ?>"    
                                          <?php else: ?>    
                                             "<?php echo e($setting['no_thanks_button_text']); ?>"
                                          <?php endif; ?>
                                       <?php else: ?>
                                          "<?php echo e($setting['no_thanks_button_text']); ?>" 
                                       <?php endif; ?>
                                     >
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="cancel" data-dismiss="modal">Cancel</button>
               <?php if(isset($upsell)): ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save update_setting">Save Changes</button>
               <?php else: ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save save_setting">Save Changes</button>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </form>
</div>
<!--------Modal-4-close-------><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/includes/components/add_to_cart_template4.blade.php ENDPATH**/ ?>