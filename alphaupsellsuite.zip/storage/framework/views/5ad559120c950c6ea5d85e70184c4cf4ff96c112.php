<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <base target="_top">

        <title>Redirecting...</title>

        <script type="text/javascript">window.top.location.href = "<?php echo $url; ?>";</script>
    </head>
    <body>
    </body>
</html><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/vendor/shopify-app/billing/fullpage_redirect.blade.php ENDPATH**/ ?>