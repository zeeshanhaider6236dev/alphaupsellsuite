<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.upsell_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
   <div class="container">
      <div class="col-md-12 tabs">
         <div class="tabs">
            <div class="tab_bg">
               <form class="upsellForm">
                  <input type="hidden" name="upsell_template_type" class="template-to-select" <?php if(isset($upsell)): ?> value = "<?php echo e($upsell->setting['upsell_template_type']); ?>" <?php else: ?> value= "1" <?php endif; ?>>
                  <ul class="nav nav-tabs" role="tablist">
                     <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#home">
                           <i class="fas fa-cogs"></i>
                              Configuration
                        </a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#menu1">
                           <i class="fa fa-image"></i>
                              Preview
                        </a>
                     </li>
                     <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#menu-fbt-video">
                            <i class="fas fa-video"></i>Video Guide
                        </a>
                     </li>
                  </ul>
                  <!----------------Tab-panes----------------->
                  <div class="tab-content mt-3">
                     <div id="home" class="tab-pane active">
                        <div class="container offer">
                           <div class="row">
                              <div class="col-md-5 offer_left">
                                 <h4>Offer Name</h4>
                                 <p>This is an internal name and won't appear on the frontend.</p>
                              </div>
                              <div class="col-md-7 offer_right">
                                 <label>Name:</label><br>
                                 <input type="text" name="name" placeholder="Enter Offer Name...!!" <?php if(isset($upsell)): ?> value = "<?php echo e($upsell->name); ?>"<?php endif; ?>>
                              </div>
                           </div>
                        </div>
                        <div class="container">
                           <div class="row">
                              <div class="col-md-5 offer_left">
                                 <h4>Select Target Products</h4>
                                 <p>
                                 Target products are those products, on which you want to show an offer. When a customer will click on Add to Cart Button, then an offer will pop up on those products.
                                 </p>
                              </div>
                              <div class="col-md-7 offer_right select_bg">
                                 <div class="row mt-2">
                                    <div class="col-md-4 select_left">
                                       <h3>Upsell will Trigger on...</h3>
                                    </div>
                                    <div class="col-md-8 select_right">
                                       <button type="button" class="save pickTProduct" data-toggle="modal"
                                          data-target="#product_modal">Pick a Product</button>
                                       <button type="button" class="cancel removeAll">Remove All</button>
                                 </div>
                                 </div>
                                 <hr>
                                 <div class="pickedTriggerOn itemContainer">
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->Tproducts->count()): ?>
                                          <?php $__currentLoopData = $upsell->Tproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <div class="box_shado mt">
                                                   <input class="tabValues" type="hidden" name="Tproducts[]" value="<?php echo e($tProduct->shopify_product_id); ?>">
                                                   <input class="tabValues" type="hidden" name="Tproductsimages[]" value="<?php echo e($tProduct->shopify_product_image); ?>">
                                                   <input class="tabValues" type="hidden" name="Tproductstitles[]" value="<?php echo e($tProduct->shopify_product_title); ?>">
                                                   <div class="row">
                                                      <div class="img_box col-md-2">
                                                         <img src="<?php echo e($tProduct->shopify_product_image); ?>">
                                                      </div>
                                                      <div class="img_name col-md-8">
                                                         <p><?php echo e($tProduct->shopify_product_title); ?>

                                                         </p>
                                                      </div>
                                                      <div class="img_btn col-md-2">
                                                         <button type="button" class="delete float-right deleteItem">Delete</button>
                                                      </div>
                                                   </div>
                                             </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php elseif($upsell->Tcollections->count()): ?>
                                          <?php $__currentLoopData = $upsell->Tcollections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tCollection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <input class="tabValues" type="hidden" name="Tcollections[]" value="<?php echo e($tCollection->shopify_collection_id); ?>">
                                             <input class="tabValues" type="hidden" name="Tcollectionsimages[]" value="<?php echo e($tCollection->shopify_collection_image); ?>">
                                             <input class="tabValues" type="hidden" name="Tcollectionstitles[]" value="<?php echo e($tCollection->shopify_collection_title); ?>">

                                             <div class="box_shado mt">
                                                   <div class="row">
                                                      <div class="img_box col-md-2">
                                                         <img src="<?php echo e($tCollection->shopify_collection_image); ?>">
                                                      </div>
                                                      <div class="img_name col-md-8">
                                                         <p><?php echo e($tCollection->shopify_collection_title); ?>

                                                         </p>
                                                      </div>
                                                      <div class="img_btn col-md-2">
                                                         <button type="button" class="delete float-right deleteItem">Delete</button>
                                                      </div>
                                                   </div>
                                             </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php elseif($upsell->Ttags->count()): ?>
                                          <?php $__currentLoopData = $upsell->Ttags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tTags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <div class="box_shado mt">
                                                   <input class="tabValues" type="hidden" name="Ttags[]" value="<?php echo e($tTags->shopify_tag_id); ?>">
                                                   <input class="tabValues" type="hidden" name="Ttagsimages[]" value="<?php echo e($tTags->shopify_tag_image); ?>">
                                                   <input class="tabValues" type="hidden" name="Ttagstitles[]" value="<?php echo e($tTags->shopify_tag_title); ?>">
                                                   <div class="row">
                                                      <div class="img_box col-md-2">
                                                         <img src="<?php echo e($tTags->shopify_tag_image); ?>">
                                                      </div>
                                                      <div class="img_name col-md-8">
                                                         <p><?php echo e($tTags->shopify_tag_title); ?>

                                                         </p>
                                                      </div>
                                                      <div class="img_btn col-md-2">
                                                         <button type="button" class="delete float-right deleteItem">Delete</button>
                                                      </div>
                                                   </div>
                                             </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                    <?php endif; ?>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="container upsel_p">
                           <div class="row">
                              <div class="col-md-5 offer_left">
                                 <h4>Select Upsell Products</h4>
                                 <p>
                                 Upsell products are those products, which you want to show in the offer. When customers click targeted products Add to Cart Button, then upsell products will be shown on offer.
                                 </p>
                              </div>
                              <div class="col-md-7 offer_right select_bg">
                                 <div class="row mt-2">
                                    <div class="col-md-4 select_left">
                                       <h3>Upsell will Appear on...</h3>
                                    </div>
                                    <div class="col-md-8 select_right">
                                       <input class="autoHidden" type="hidden" name="auto" value="<?php echo e(isset($upsell) && $upsell->auto ? '1' : '0'); ?>">
                                        <button id="ppu_button"type="button" class="autoButton ppu-auto-button <?php echo e(isset($upsell) && $upsell->auto ? 'autoTrue save' : 'delete'); ?>">Auto</button>
                                       <button type="button" class="save pickAProduct" data-toggle="modal"
                                          data-target="#product_modal">Pick a Product</button>
                                       <button type="button" class="cancel removeAll">Remove All</button>
                                 </div>
                                 </div>
                                 <hr>
                                 <div>
                                    <div id="auto-collapse-box" class="collapse itemContainer item-container-auto-module" style="display:block;">
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->auto): ?>
                                           <div class="box_shado mt" style="display: flex; align-items: center;">
                                               <div class="img_box col-md-2" style="width: 100%;"> <img src="https://i.ibb.co/zP4drmC/Pngtree-artificial-intelligence-chip-icon-for-4864546.png" alt="error loading image "></div>
                                               <div>
                                                   <span>Our AI analysis the previous purchases in your store through data mining algorithm & produce memory graph with recommended products that are usually added.</span>
                                               </div>
                                               <div class="img_btn col-md-2">
                                                   <button id="delete_button_auto" type="button" class="delete float-right">Delete</button>
                                               </div>
                                           </div>
                                       <?php endif; ?>
                                    <?php endif; ?>
                                    </div>
                                 </div>
                                 <div class="pickedAppearOn itemContainer">
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->Aproducts->count()): ?>
                                          <?php $__currentLoopData = $upsell->Aproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <div class="box_shado mt">
                                                   <input class="tabValues" type="hidden" name="Aproducts[]" value="<?php echo e($aProduct->shopify_product_id); ?>">
                                                   <input class="tabValues" type="hidden" name="Aproductsimages[]" value="<?php echo e($aProduct->shopify_product_image); ?>">
                                                   <input class="tabValues" type="hidden" name="Aproductstitles[]" value="<?php echo e($aProduct->shopify_product_title); ?>">
                                                   <div class="row">
                                                      <div class="img_box col-md-2">
                                                         <img src="<?php echo e($aProduct->shopify_product_image); ?>">
                                                      </div>
                                                      <div class="img_name col-md-8">
                                                         <p><?php echo e($aProduct->shopify_product_title); ?>

                                                         </p>
                                                      </div>
                                                      <div class="img_btn col-md-2">
                                                         <button type="button" class="delete float-right deleteItem">Delete</button>
                                                      </div>
                                                   </div>
                                             </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php elseif($upsell->Acollections->count()): ?>
                                          <?php $__currentLoopData = $upsell->Acollections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aCollection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <div class="box_shado mt">
                                                   <input class="tabValues" type="hidden" name="Acollections[]" value="<?php echo e($aCollection->shopify_collection_id); ?>">
                                                   <input class="tabValues" type="hidden" name="Acollectionsimages[]" value="<?php echo e($aCollection->shopify_collection_image); ?>">
                                                   <input class="tabValues" type="hidden" name="Acollectionstitles[]" value="<?php echo e($aCollection->shopify_collection_title); ?>">
                                                   <div class="row">
                                                      <div class="img_box col-md-2">
                                                         <img src="<?php echo e($aCollection->shopify_collection_image); ?>">
                                                      </div>
                                                      <div class="img_name col-md-8">
                                                         <p><?php echo e($aCollection->shopify_collection_title); ?>

                                                         </p>
                                                      </div>
                                                      <div class="img_btn col-md-2">
                                                         <button type="button" class="delete float-right deleteItem">Delete</button>
                                                      </div>
                                                   </div>
                                             </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php elseif($upsell->Atags->count()): ?>
                                          <?php $__currentLoopData = $upsell->Atags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aTags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <div class="box_shado mt">
                                                   <input class="tabValues" type="hidden" name="Atags[]" value="<?php echo e($aTags->shopify_tag_id); ?>">
                                                   <input class="tabValues" type="hidden" name="Atagsimages[]" value="<?php echo e($aTags->shopify_tag_image); ?>">
                                                   <input class="tabValues" type="hidden" name="Atagstitles[]" value="<?php echo e($aTags->shopify_tag_title); ?>">
                                                   <div class="row">
                                                      <div class="img_box col-md-2">
                                                         <img src="<?php echo e($aTags->shopify_tag_image); ?>">
                                                      </div>
                                                      <div class="img_name col-md-8">
                                                         <p><?php echo e($aTags->shopify_tag_title); ?>

                                                         </p>
                                                      </div>
                                                      <div class="img_btn col-md-2">
                                                         <button type="button" class="delete float-right deleteItem">Delete</button>
                                                      </div>
                                                   </div>
                                             </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php endif; ?>
                                    <?php endif; ?>
                                 </div>



                              </div>
                           </div>
                        </div>
                        <div class="container offer">
                           <div class="row">
                              <div class="col-md-5 offer_left">
                                 <h4>Discount Details</h4>
                                 <p>
                                    Choose the discount type here whether you want to apply discount in percentage, a fix price or no discount.
                                 </p>
                              </div>
                              <div class="col-md-7 offer_right">
                                 <div class="row">
                                    <div class="col-md-6 discount_left">
                                       <label>Discount Type:</label><br>
                                       <select name="discount_type">
                                          <option <?php if(isset($upsell)): ?>
                                                   <?php echo e($upsell->setting['discount_type'] == "% Off" ? "selected" : ''); ?>

                                             <?php else: ?>
                                                   <?php echo e($upsellType->setting['discount_type'] == "% Off" ? "selected" : ''); ?>

                                             <?php endif; ?>
															value="% Off">% Off
                                          </option>
                                          <option <?php if(isset($upsell)): ?>
                                                      <?php echo e($upsell->setting['discount_type'] == "Fixed Price Off" ? "selected" : ''); ?>

                                                <?php else: ?>
                                                      <?php echo e($upsellType->setting['discount_type'] == "Fixed Price Off" ? "selected" : ''); ?>

                                                <?php endif; ?>
															value="Fixed Price Off">Fixed Price Off
                                          </option>
                                          
                                       </select>
                                    </div>
                                    <div class="col-md-6 discount_left">
                                       <label>Discount Value:</label><br>
                                       <input type="number" name="discount_value" value=
                                          <?php if(isset($upsell)): ?>
															"<?php echo e($upsell->setting['discount_value']); ?>"
														<?php else: ?>
															"<?php echo e($upsellType->setting['discount_value']); ?>"
														<?php endif; ?>
														min="0"
                                       />
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="container">
                           <div class="row">
                              <div class="col-md-5 offer_left">
                                 <h4>Optional Settings</h4>
                                 <p></p>
                              </div>
                              <div class="col-md-7 select_bg display">
                                 <h4>Work on device:</h4>
                                    <div class="row">
                                       <div class="form-check form_float ml-3">
                                          <input type="checkbox" value="1" class="form-check-input" id="formCheck-1" style="height: 20px;" name="work_on_desktop"
                                          <?php if(isset($upsell)): ?>
                                             <?php echo e($upsell->setting['work_on_desktop']  ? "checked" : ''); ?>

                                          <?php else: ?>
                                             <?php echo e($upsellType->setting['work_on_desktop']  ? "checked" : ''); ?>

                                          <?php endif; ?>
                                          />
                                          <label class="form-check-label" for="formCheck-1">
                                             Desktop
                                          </label>
                                       </div>
                                       <div class="form-check form_float">
                                          <input type="checkbox" value="1" class="form-check-input" id="formCheck-3" style="height: 20px;" name="work_on_mobile"
                                          <?php if(isset($upsell)): ?>
                                             <?php echo e($upsell->setting['work_on_mobile']  ? "checked" : ''); ?>

                                          <?php else: ?>
                                             <?php echo e($upsellType->setting['work_on_mobile']  ? "checked" : ''); ?>

                                          <?php endif; ?>
                                          />
                                          <label class="form-check-label" for="formCheck-3">
                                             Mobile
                                          </label>
                                       </div>
                                    </div>
                                 <hr>
                                 <h4>Schedule:</h4>
                                 <div class="row">
                                 <div class="col-md-6 discount_left">
                                       <label>Start Date:</label><br>
                                       <input value=
														<?php if(isset($upsell)): ?>
															"<?php echo e($upsell->setting['start_date']); ?>"
														<?php else: ?>
															"<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>"
														<?php endif; ?>
                                          name="start_date" type="date"
                                       />
                                 </div>
                                 <div class="col-md-6 discount_left">
                                       <label>End Date:</label><br>
                                       <input class="end_date" name="end_date" type="date" style="background-color: #dadada;" />
                                 </div>
                              </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!----------tab-1-close----------->
                     <div id="menu1" class="tab-pane fade p-0">
                        <h2 class="choose_h">Choose A Funnel Template</h2>
                        <div class="row">
                           <div class="col-md-4 template_1 popup-box-color" ">
                              <?php if(isset($upsell)): ?>
                                 <?php if( $upsell->setting['upsell_template_type'] == 1): ?>
                                    <div class="alpha_t_u_choosen">
                                       <span>&#10003;</span>
                                    </div>
                                 <?php endif; ?>
                              <?php else: ?>
                                 <div class="alpha_t_u_choosen">
                                    <span>&#10003;</span>
                                 </div>
                              <?php endif; ?>
                              <div class="popup_1 <?php if(isset($upsell)): ?> <?php echo e($upsell->setting['upsell_template_type'] == 1 ? "select_popup":''); ?> <?php else: ?> <?php echo e("select_popup"); ?> <?php endif; ?>" style="background-color: white !important;">
                                 <div data-toggle="modal" data-target="#centralModalSm">
                                    <a href="#lightbox" data-slide-to="0">
                                       <img src="<?php echo e(asset('assets')); ?>/img/template-1.jpg" alt=""></a>
                                 </div>
                                 <button type="button" class="save select-template" data-toggle="modal" data-target="#centralModalSm">Select Template</button>
                              </div>
                           </div>
                           <div class="col-md-4 template_2 popup-box-color">
                              <?php if(isset($upsell)): ?>
                                 <?php if( $upsell->setting['upsell_template_type'] == 2): ?>
                                    <div class="alpha_t_u_choosen">
                                       <span>&#10003;</span>
                                    </div>
                                 <?php endif; ?>
                              <?php endif; ?>
                              <div class="popup_1 <?php if(isset($upsell)): ?> <?php echo e($upsell->setting['upsell_template_type'] == 2 ? "select_popup":''); ?> <?php endif; ?>" style="background-color: white !important;">
                                 <div data-toggle="modal" data-target="#centralModalSm2">
                                    <a href="#lightbox" data-slide-to="1">
                                       <img src="<?php echo e(asset('assets')); ?>/img/template-2.jpg" alt="">
                                    </a>
                                 </div>
                                 <button type="button" class="save select-template" data-toggle="modal" data-target="#centralModalSm2">
                                    Select Template
                                 </button>
                              </div>
                           </div>
                           <div class="col-md-4 template_3 popup-box-color" >
                              <?php if(isset($upsell)): ?>
                                 <?php if( $upsell->setting['upsell_template_type'] == 3): ?>
                                    <div class="alpha_t_u_choosen">
                                       <span>&#10003;</span>
                                    </div>
                                 <?php endif; ?>
                              <?php endif; ?>
                              <div class="popup_1 <?php if(isset($upsell)): ?> <?php echo e($upsell->setting['upsell_template_type'] == 3 ? "select_popup":''); ?> <?php endif; ?>" style="background-color: white !important;">
                                 <div data-toggle="modal" data-target="#centralModalSm3">
                                    <a href="#lightbox" data-slide-to="2">
                                       <img src="<?php echo e(asset('assets')); ?>/img/template-3.jpg" alt="">
                                    </a>
                                 </div>
                                 <button type="button" class="save select-template" data-toggle="modal" data-target="#centralModalSm3">
                                    Select Template
                                 </button>
                              </div>
                           </div>
                        </div>
                        <div class="row mt-4 ">
                           <div class="col-md-4 template_4 popup-box-color" >
                              <?php if(isset($upsell)): ?>
                                 <?php if( $upsell->setting['upsell_template_type'] == 4): ?>
                                    <div class="alpha_t_u_choosen">
                                       <span>&#10003;</span>
                                    </div>
                                 <?php endif; ?>
                              <?php endif; ?>
                              <div class="popup_1 <?php if(isset($upsell)): ?> <?php echo e($upsell->setting['upsell_template_type'] == 4 ?"select_popup":''); ?> <?php endif; ?>" style="background-color: white !important;">
                                 <div data-toggle="modal" data-target="#centralModalSm4">
                                    <a href="#lightbox" data-slide-to="3">
                                       <img src="<?php echo e(asset('assets')); ?>/img/template-4.jpg" alt="">
                                    </a>
                                 </div>
                                 <button type="button" class="save select-template" data-toggle="modal" data-target="#centralModalSm4">
                                    Select Template
                                 </button>
                              </div>
                           </div>
                           <div class="col-md-4 template_5 popup-box-color" >
                              <?php if(isset($upsell)): ?>
                                 <?php if( $upsell->setting['upsell_template_type'] == 5): ?>
                                    <div class="alpha_t_u_choosen">
                                       <span>&#10003;</span>
                                    </div>
                                 <?php endif; ?>
                              <?php endif; ?>
                              <div class="popup_1 <?php if(isset($upsell)): ?> <?php echo e($upsell->setting['upsell_template_type'] == 5 ?"select_popup":''); ?> <?php endif; ?>" style="background-color: white !important;">
                                 <div data-toggle="modal" data-target="#centralModalSm5">
                                    <a href="#lightbox" data-slide-to="4">
                                       <img src="<?php echo e(asset('assets')); ?>/img/template-5.jpg" alt="">
                                    </a>
                                 </div>
                                 <button type="button" class="save select-template" data-toggle="modal" data-target="#centralModalSm5">
                                    Select Template
                                 </button>
                              </div>
                           </div>
                           <div class="col-md-4 template_6 popup-box-color">
                              <?php if(isset($upsell)): ?>
                                 <?php if( $upsell->setting['upsell_template_type'] == 6): ?>
                                    <div class="alpha_t_u_choosen">
                                       <span>&#10003;</span>
                                    </div>
                                 <?php endif; ?>
                              <?php endif; ?>
                              <div class="popup_1 <?php if(isset($upsell)): ?> <?php echo e($upsell->setting['upsell_template_type'] == 6 ?"select_popup":''); ?> <?php endif; ?>"  style="background-color: white !important;">
                                 <div data-toggle="modal" data-target="#centralModalSm6">
                                    <a href="#lightbox" data-slide-to="5">
                                       <img src="<?php echo e(asset('assets')); ?>/img/template-6-fix.jpg" alt="">
                                    </a>
                                 </div>
                                 <button type="button" class="save select-template" data-toggle="modal" data-target="#centralModalSm6">
                                    Select Template
                                 </button>
                              </div>
                           </div>
                        </div>
                        <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="Lightbox Gallery by Bootstrap 4" aria-hidden="true">
                           <div class="modal-dialog modal-dialog-centered modal_w" role="document">
                              <div class="modal-content">
                                 <div class="modal-body">
                                    <div id="lightbox" class="carousel slide" data-ride="carousel" data-interval="8000" data-keyboard="true">
                                       <ol class="carousel-indicators">
                                          <li data-target="#lightbox" data-slide-to="0"></li>
                                          <li data-target="#lightbox" data-slide-to="1"></li>
                                          <li data-target="#lightbox" data-slide-to="2"></li>
                                          <li data-target="#lightbox" data-slide-to="3"></li>
                                          <li data-target="#lightbox" data-slide-to="4"></li>
                                          <li data-target="#lightbox" data-slide-to="5"></li>
                                       </ol>
                                       <div class="carousel-inner">
                                          <div class="carousel-item active">
                                             <img src="<?php echo e(asset('assets')); ?>/img/template-1.jpg" class="w-100" alt="">
                                          </div>
                                          <div class="carousel-item">
                                             <img src="<?php echo e(asset('assets')); ?>/img/template-2.jpg" class="w-100" alt="">
                                          </div>
                                          <div class="carousel-item">
                                             <img src="<?php echo e(asset('assets')); ?>/img/template-3.jpg" class="w-100" alt="">
                                          </div>
                                          <div class="carousel-item">
                                             <img src="<?php echo e(asset('assets')); ?>/img/template-4.jpg" class="w-100" alt="">
                                          </div>
                                          <div class="carousel-item">
                                             <img src="<?php echo e(asset('assets')); ?>/img/template-5.jpg" class="w-100" alt="">
                                          </div>
                                          <div class="carousel-item">
                                             <img src="<?php echo e(asset('assets')); ?>/img/template-6-fix.jpg" class="w-100" alt="">
                                          </div>
                                       </div>
                                       <a class="carousel-control-prev" href="#lightbox" role="button" data-slide="prev">
                                          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                          <span class="sr-only">Previous</span>
                                       </a>
                                       <a class="carousel-control-next" href="#lightbox" role="button" data-slide="next">
                                          <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                          <span class="sr-only">Next</span>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-----------------Tab-2-Close----------------->
                     <div id="menu-fbt-video" class="tab-pane fade p-0"><br><div class="container-fluid">
                        <div class="container">
                           <div class="row">
                              <div class="col-md-12">
                                 <iframe width="100%" height="515" src="https://www.youtube.com/embed/aU7EStux9aY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                              </div>
                           </div>
                        </div>
                        </div>
                     </div>

                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!-----------All Templates---------->
<?php $__currentLoopData = $upsellTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <?php echo $__env->make('includes.components.add_to_cart_template'.($key+1),['setting' => $upsellTemplates[$key]->setting,'upsellTemplateId' => $upsellTemplates[$key]->id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('includes.components.pickProductModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.pages.add_to_cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.shopify-app.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/pre_purchase.blade.php ENDPATH**/ ?>