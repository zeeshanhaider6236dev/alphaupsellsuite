﻿
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.upsell_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
   <div class="container">
      <div class="col-md-12 tabs">
         <div class="tabs">
            <div class="tab_bg">
            <form class="upsellForm">
               <ul class="nav nav-tabs" role="tablist">
                  <li class="nav-item">
                      <a class="nav-link active" data-toggle="tab" href="#home">
                          <i class="fas fa-cogs"></i>
                          Configuration
                       </a>
                    </li>
                  <li class="nav-item">
                      <a class="nav-link" data-toggle="tab" href="#menu1">
                          <i class="fa fa-image"></i>
                          Preview
                        </a>
                    </li>

                    <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#menu-fbt-video">
                                <i class="fas fa-video"></i>Video Guide
                                </a>
                    </li>
               </ul>
               <!----------------Tab-panes----------------->
               <div class="tab-content mt-3">
                  <div id="home" class="tab-pane active">
                     <div class="container offer">
                        <div class="row">
                           <div class="col-md-5 offer_left">
                              <h4>Offer Name</h4>
                              <p>This is an internal name and won't appear on the frontend.</p>
                           </div>
                           <div class="col-md-7 offer_right">
                              <label for="offer_name">Name:</label><br>
                              <?php
                                  if(isset($upsell)):
                                      $name = $upsell['name'];
                                  else:
                                      $name = '';
                                  endif;
                              ?>
                              <input type="text" placeholder="Enter Offer Name...!!" id="offer_name" name="name" value="<?php echo e($name); ?>">
                           </div>
                        </div>
                     </div>
                     <div class="container">
                        <div class="row">
                           <div class="col-md-5 offer_left">
                              <h4>Select Target Products</h4>
                              <p>
                              Target products are those products, on which you want to show an offer. Display your volume and quantity base discount on your product pages.
                              </p>
                           </div>
                           <div class="col-md-7 offer_right select_bg">
                              <div class="row mt-2">
                                 <div class="col-md-4 select_left">
                                    <h3>Upsell will Trigger on...</h3>
                                 </div>
                                 <div class="col-md-8 select_right">
                                    <button type="button" class="save pickTProduct" data-toggle="modal"
                                    data-target="#product_modal">
                                        Pick a Product
                                    </button>
                                    <button type="button" class="cancel removeAll">Remove All</button>
                                 </div>
                              </div>
                              <hr>
                              <div class="pickedTriggerOn itemContainer">
                                <?php if(isset($upsell)): ?>
                                      <?php if($upsell->Tproducts->count()): ?>
                                          <?php $__currentLoopData = $upsell->Tproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <div class="box_shado mt">
                                                  <input class="tabValues" type="hidden" name="Tproducts[]" value="<?php echo e($tProduct->shopify_product_id); ?>">
                                                  <input class="tabValues" type="hidden" name="Tproductsimages[]" value="<?php echo e($tProduct->shopify_product_image); ?>">
                                                  <input class="tabValues" type="hidden" name="Tproductstitles[]" value="<?php echo e($tProduct->shopify_product_title); ?>">
                                                  <div class="row">
                                                      <div class="img_box col-md-2">
                                                          <img src="<?php echo e($tProduct->shopify_product_image); ?>">
                                                      </div>
                                                      <div class="img_name col-md-8">
                                                          <p><?php echo e($tProduct->shopify_product_title); ?>

                                                          </p>
                                                      </div>
                                                      <div class="img_btn col-md-2">
                                                          <button type="button" class="delete float-right deleteItem">Delete</button>
                                                      </div>
                                                  </div>
                                              </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php elseif($upsell->Tcollections->count()): ?>
                                          <?php $__currentLoopData = $upsell->Tcollections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tCollection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <input class="tabValues" type="hidden" name="Tcollections[]" value="<?php echo e($tCollection->shopify_collection_id); ?>">
                                              <input class="tabValues" type="hidden" name="Tcollectionsimages[]" value="<?php echo e($tCollection->shopify_collection_image); ?>">
                                              <input class="tabValues" type="hidden" name="Tcollectionstitles[]" value="<?php echo e($tCollection->shopify_collection_title); ?>">
                                              <div class="box_shado mt">
                                                  <div class="row">
                                                      <div class="img_box col-md-2">
                                                          <img src="<?php echo e($tCollection->shopify_collection_image); ?>">
                                                      </div>
                                                      <div class="img_name col-md-8">
                                                          <p><?php echo e($tCollection->shopify_collection_title); ?>

                                                          </p>
                                                      </div>
                                                      <div class="img_btn col-md-2">
                                                          <button type="button" class="delete float-right deleteItem">Delete</button>
                                                      </div>
                                                  </div>
                                              </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php elseif($upsell->Ttags->count()): ?>
                                          <?php $__currentLoopData = $upsell->Ttags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tTags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <div class="box_shado mt">
                                                  <input class="tabValues" type="hidden" name="Ttags[]" value="<?php echo e($tTags->shopify_tag_id); ?>">
                                                  <input class="tabValues" type="hidden" name="Ttagsimages[]" value="<?php echo e($tTags->shopify_tag_image); ?>">
                                                  <input class="tabValues" type="hidden" name="Ttagstitles[]" value="<?php echo e($tTags->shopify_tag_title); ?>">
                                                  <div class="row">
                                                      <div class="img_box col-md-2">
                                                          <img src="<?php echo e($tTags->shopify_tag_image); ?>">
                                                      </div>
                                                      <div class="img_name col-md-8">
                                                          <p><?php echo e($tTags->shopify_tag_title); ?>

                                                          </p>
                                                      </div>
                                                      <div class="img_btn col-md-2">
                                                          <button type="button" class="delete float-right deleteItem">Delete</button>
                                                      </div>
                                                  </div>
                                              </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php endif; ?>
                                <?php endif; ?>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="container upsel_p">
                        <div class="row">
                           <div class="col-md-5 offer_left">
                              <h4>Volume Discount Offer</h4>
                              <p>
                              Encourage customers to add more products to carts with offers like : 20% off or Save $10.
                              </p>
                           </div>
                           <div class="col-md-7 offer_right select_bg">
                           <div class="pickVolume itemContainer">
                              <?php if(isset($upsell)): ?>
                                <?php if($upsell->volumeDiscounts->count()): ?>
                                  <?php $__currentLoopData = $upsell->volumeDiscounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $volumeDiscount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="row bg_hover volumeDiv">
                                    <div class="offer_qty col-md-2">
                                        <label>Quantity</label><br>
                                        <input type="number" value="<?php echo e($volumeDiscount->quantity); ?>" min="1" name="quantity[]">
                                    </div>
                                    <div class="offer_disc col-md-3">
                                        <label>Discount:</label><br>
                                        <input type="number" value="<?php echo e($volumeDiscount->discount); ?>" name="discount[]">
                                        <select name="offer[]">
                                            <?php if($volumeDiscount->discount_type == "% Off"): ?>
                                               <option value="<?php echo e($volumeDiscount->discount_type); ?>"selected><?php echo e($volumeDiscount->discount_type); ?></option>
                                               <option value="Fixed Amount">Fixed Amount</option>
                                               
                                            <?php elseif($volumeDiscount->discount_type == "Fixed Amount"): ?>
                                              <option value="<?php echo e($volumeDiscount->discount_type); ?>" selected><?php echo e($volumeDiscount->discount_type); ?></option>
                                              <option value="% Off">% Off</option>
                                              
                                            
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="offer_most col-md-7">
                                        <div class="row">
                                          <div class="col-md-6">
                                            <label>Best Deal</label><br>
                                            <div class="custom-control custom-checkbox custom-control-inline">
                                                <?php
                                                    if($volumeDiscount->best_deal == 1):
                                                        $best_deal = 1;
                                                    else:
                                                        $best_deal = 0;
                                                    endif;
                                                    $index = $loop->index;
                                                ?>

                                                <input type="hidden" name="bestdeal[]" value="<?php echo e($best_deal); ?>" class="class_one">
                                                <input type="checkbox" class="custom-control-input" id="defaultInline<?php echo e($index); ?>" <?php echo e($best_deal == 1 ? "checked" : ''); ?>>
                                                <label class="custom-control-label" for="defaultInline<?php echo e($index); ?>"></label>
                                            </div>
                                          </div>
                                          <div class="col-md-6 text-right">
                                            <i class="far fa-trash-alt alpha-upsell-deal-delete" title="click to delete deal"></i>
                                          </div>
                                        </div>
                                        <!-- <i class="fa fa-trash-o"></i> -->
                                    </div>
                                  </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                             <?php else: ?>
                            <!---- First Deal--->
                           <div class="row bg_hover volumeDiv">
                            <div class="offer_qty col-md-2">
                                <label>Quantity</label><br>
                                <input type="number" value="<?php echo e($upsellType->setting['quantity']); ?>" min="1" name="quantity[]">
                            </div>
                            <div class="offer_disc col-md-3">
                                <label>Discount:</label><br>
                                <input type="number" value="<?php echo e($upsellType->setting['discount']); ?>" name="discount[]">
                                <select name="offer[]">
                                    <option value="<?php echo e($upsellType->setting['offer']); ?>"selected>% Off</option>
                                    <option value="Fixed Amount">Fixed Amount</option>
                                    
                                </select>
                            </div>
                            <div class="offer_most col-md-7">
                                <div class="row">
                                  <div class="col-md-6">
                                    <label>Best Deal</label><br>
                                    <div class="custom-control custom-checkbox custom-control-inline">
                                        <input type="hidden" name="bestdeal[]" value="0" class="class_one">
                                        <input type="checkbox" class="custom-control-input deal1" id="defaultInline1">
                                        <label class="custom-control-label" for="defaultInline1"></label>
                                    </div>
                                  </div>
                                  <div class="col-md-6 text-right">
                                    <i class="far fa-trash-alt alpha-upsell-deal-delete" title="click to delete deal"></i>
                                  </div>
                                </div>
                                <!-- <i class="fa fa-trash-o"></i> -->
                            </div>
                          </div>
                          <!---- End Of First Deal--->
                          <!---- Second Deal--->
                          <div class="row bg_hover volumeDiv">
                            <div class="offer_qty col-md-2">
                                <label>Quantity</label><br>
                                <input type="number" value="<?php echo e($upsellType->setting['quantity']); ?>" min="1" name="quantity[]">
                            </div>
                            <div class="offer_disc col-md-3">
                                <label>Discount:</label><br>
                                <input type="number" value="<?php echo e($upsellType->setting['discount']); ?>" name="discount[]">
                                <select name="offer[]">
                                    <option value="<?php echo e($upsellType->setting['offer']); ?>"selected>% Off</option>
                                    <option value="Fixed Amount">Fixed Amount</option>
                                    
                                </select>
                            </div>
                            <div class="offer_most col-md-7">
                               <div class="row">
                                  <div class="col-md-6">
                                    <label>Best Deal</label><br>
                                    <div class="custom-control custom-checkbox custom-control-inline">
                                        <input type="hidden" name="bestdeal[]" value="1" class="class_one">
                                        <input type="checkbox" class="custom-control-input deal2" id="defaultInline2" value="1" checked>
                                        <label class="custom-control-label" for="defaultInline2"></label>
                                    </div>
                                  </div>
                                  <div class="col-md-6 text-right">
                                    <i class="far fa-trash-alt alpha-upsell-deal-delete" title="click to delete deal"></i>
                                  </div>
                                </div>
                                
                            </div>
                          </div>
                          <!---- End Of Second Deal--->
                          <!---- Third Deal--->
                          <div class="row bg_hover volumeDiv">
                            <div class="offer_qty col-md-2">
                                <label>Quantity</label><br>
                                <input type="number" value="<?php echo e($upsellType->setting['quantity']); ?>" min="1" name="quantity[]">
                            </div>
                            <div class="offer_disc col-md-3">
                                <label>Discount:</label><br>
                                <input type="number" value="<?php echo e($upsellType->setting['discount']); ?>" name="discount[]">
                                <select name="offer[]">
                                    <option value="<?php echo e($upsellType->setting['offer']); ?>"selected>% Off</option>
                                    <option value="Fixed Amount">Fixed Amount</option>
                                    
                                </select>
                            </div>
                            <div class="offer_most col-md-7">
                                <div class="row">
                                  <div class="col-md-6">
                                    <label>Best Deal</label><br>
                                    <div class="custom-control custom-checkbox custom-control-inline">
                                        <input type="hidden" name="bestdeal[]" value="0" class="class_one">
                                        <input type="checkbox" class="custom-control-input deal3" id="defaultInline3">
                                        <label class="custom-control-label" for="defaultInline3"></label>
                                    </div>
                                  </div>
                                  <div class="col-md-6 text-right">
                                    <i class="far fa-trash-alt alpha-upsell-deal-delete" title="click to delete deal"></i>
                                  </div>
                                </div>
                                <!-- <i class="fa fa-trash-o"></i> -->
                            </div>
                          </div>
                          <?php endif; ?>
                          <!---- End Of Third Deal--->
                            </div>
                              <button type="button" class="save btn_f addNewVolume">
                                  Add Volume Row
                              </button>
                           </div>
                        </div>
                     </div>
                     <div class="container mt-4">
                        <div class="row">
                           <div class="col-md-5 offer_left">
                              <h4>Optional Settings</h4>
                              <p></p>
                           </div>
                           <div class="col-md-7 select_bg display">
                              <h4>Work on device:</h4>
                              <p>
                                <div class="row">
                                    <div class="form-check form_float ml-3">
                                        <?php
                                            if(isset($upsell)):
                                                $work_on_desktop = $upsell['setting']['work_on_desktop'];
                                            else:
                                                $work_on_desktop = $upsellType->setting['work_on_desktop'];
                                            endif;
                                        ?>
                                        <input <?php echo e($work_on_desktop == 1 ? "checked" : ''); ?> name="work_on_desktop" type="checkbox" class="form-check-input" id="formCheck-1"
                                        style="height: 20px;" value="1"  checked>
                                        <label class="form-check-label" for="formCheck-1">Desktop</label>
                                    </div>
                                    <div class="form-check form_float">
                                        <?php
                                            if(isset($upsell)):
                                                $work_on_mobile = $upsell['setting']['work_on_mobile'];
                                            else:
                                                $work_on_mobile = $upsellType->setting['work_on_mobile'];
                                            endif;
                                        ?>
                                        <input <?php echo e($work_on_mobile == 1  ? "checked" : ''); ?> name="work_on_mobile" type="checkbox" class="form-check-input" id="formCheck-3"
                                        style="height: 20px;" value="1" checked>
                                        <label class="form-check-label" for="formCheck-3">Mobile</label>
                                    </div>
                                </div>
                              </p>
                              <hr>
                              <h4>Schedule:</h4>
                              <div class="row">
                                <div class="col-md-6 discount_left">
                                  <label>Start Date:</label><br>
                                  <?php
                                  if(isset($upsell)):
                                      $start_date = $upsell['setting']['start_date'];
                                  else:
                                      $start_date = \Carbon\Carbon::now()->format('Y-m-d');
                                  endif;
                                  ?>
                                  <input value="<?php echo e($start_date); ?>" name="start_date" type="date">
                              </div>
                              <div class="col-md-6 discount_left">
                                  <label>End Date:</label><br>
                                  <?php
                                    if(isset($upsell)):
                                        $end_date = $upsell['setting']['end_date'];
                                        $style = "background-color: #fffdfd;";
                                    else:
                                        $end_date = '';
                                        $style = "background-color: #dadada;";
                                    endif;
                                  ?>
                                  <input value="<?php echo e($end_date); ?>" name="end_date" type="date" id="end_date" style="<?php echo e($style); ?>">
                              </div>
                            </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-------------------tab-1-close--------------------->
                  <div id="menu1" class="tab-pane fade p-0">
                     <br>
                     <div class="container-fluid">
                        <div class="container">
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="design_input">
                                    <h3>Title</h3>
                                    <p class="h_input">
                                        <label>Heading</label><br>
                                        <?php
                                            if(isset($upsell)):
                                                $volume_discount_heading = $upsell['setting']['volume_discount_heading'];
                                            else:
                                                $volume_discount_heading = $upsellType->setting['volume_discount_heading'];
                                            endif;
                                        ?>
                                        <input type="text" value="<?php echo e($volume_discount_heading); ?>" name="volume_discount_heading">
                                    </p>
                                    <div class="col-md-12 font">
                                        <div class="row">
                                            <p class="f_input">
                                                <label>Font family</label><br>
                                                <select name="heading_font_family">
                                                    <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option
                                                        <?php if(isset($upsell)): ?>
                                                            <?php if($upsell['setting']['heading_font_family'] == $family): ?>
                                                                <?php echo e("selected"); ?>

                                                            <?php endif; ?>
                                                        <?php elseif($upsellType->setting['heading_font_family'] == $family): ?>
                                                            <?php echo e("selected"); ?>

                                                        <?php endif; ?>
                                                    value="<?php echo e($family); ?>">
                                                        <?php echo e($family); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </p>
                                            <p class="f_input">
                                                <label>Font Size</label><br>
                                                <?php
                                                    if(isset($upsell)):
                                                        $heading_font_size = $upsell['setting']['heading_font_size'];
                                                    else:
                                                        $heading_font_size = $upsellType->setting['heading_font_size'];
                                                    endif;
                                                ?>
                                                <input type="number" value="<?php echo e($heading_font_size); ?>" min="12" name="heading_font_size">
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-12 font">
                                        <div class="row">
                                            <div class="f_input_color">
                                                <label>Color</label><br>
                                                <?php
                                                    if(isset($upsell)):
                                                        $heading_color = $upsell['setting']['heading_color'];
                                                    else:
                                                        $heading_color = $upsellType->setting['heading_color'];
                                                    endif;
                                                ?>
                                                <a href="#" class="buttoncolor colorpicker"   data-id="heading_color" style="background-color:<?php echo e($heading_color); ?> ">
                                                </a>
                                                <input value="<?php echo e($heading_color); ?>" type="hidden" name="heading_color">
                                                <p>Text Color </p>
                                            </div>
                                            <div class="f_input">
                                                <label>Text Align</label><br>
                                                <?php
                                                    if(isset($upsell)):
                                                        $heading_align = $upsell['setting']['heading_align'];
                                                    else:
                                                        $heading_align = $upsellType->setting['heading_align'];
                                                    endif;
                                                ?>
                                                <select name="heading_align">
                                                    <option <?php echo e($heading_align == "left" ? "selected" : ''); ?>       value="left">Left</option>
                                                    <option <?php echo e($heading_align == "center" ? "selected" : ''); ?>     value="center">Center</option>
                                                    <option <?php echo e($heading_align == "right" ? "selected" : ''); ?> value="right">Right</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <h3 class="mt-4">Color Settings</h3>
                                    <div class="col-md-12 font">
                                       <div class="row">
                                          <div class="f_input_color mt-3">
                                            <?php
                                                if(isset($upsell)):
                                                    $quantity_color = $upsell['setting']['quantity_color'];
                                                else:
                                                    $quantity_color = $upsellType->setting['quantity_color'];
                                                endif;
                                            ?>
                                             <a href="#" class="buttoncolor colorpicker" data-id="quantity_color" style="background-color:<?php echo e($quantity_color); ?>;">
                                             </a>
                                             <input value="<?php echo e($quantity_color); ?>" type="hidden" name="quantity_color">
                                             <p>Quanity </p>
                                          </div>
                                          <div class="f_input_color mt-3">
                                            <?php
                                                if(isset($upsell)):
                                                    $best_deal_color = $upsell['setting']['best_deal_color'];
                                                else:
                                                    $best_deal_color = $upsellType->setting['best_deal_color'];
                                                endif;
                                            ?>
                                             <a href="#" class="buttoncolor colorpicker" data-id="best_deal_color" style="background-color:<?php echo e($best_deal_color); ?>;">
                                             </a>
                                             <input value="<?php echo e($best_deal_color); ?>" type="hidden" name="best_deal_color">
                                             <p>Best Deal Background</p>
                                          </div>
                                          <div class="f_input_color mt-3">
                                            <?php
                                                if(isset($upsell)):
                                                    $original_total_price_color = $upsell['setting']['original_total_price_color'];
                                                else:
                                                    $original_total_price_color = $upsellType->setting['original_total_price_color'];
                                                endif;
                                            ?>
                                             <a href="#" class="buttoncolor colorpicker" data-id="original_total_price_color" style="background-color: <?php echo e($original_total_price_color); ?>;">
                                             </a>
                                             <input value="<?php echo e($original_total_price_color); ?>" type="hidden" name="original_total_price_color">
                                             <p>Original Total Price</p>
                                          </div>
                                          <div class="f_input_color mt-3">
                                             <a href="#" class="buttoncolor colorpicker" data-id="discount_total_price_color" style="background-color: <?php echo e($upsellType->setting['discount_total_price_color']); ?>;">
                                             </a>
                                             <input value="<?php echo e($upsellType->setting['discount_total_price_color']); ?>" type="hidden" name="discount_total_price_color">
                                             <p>Discount Total Price</p>
                                          </div>
                                          <div class="f_input_color mt-3">
                                            <?php
                                                if(isset($upsell)):
                                                    $discount_badge_text_color = $upsell['setting']['discount_badge_text_color'];
                                                else:
                                                    $discount_badge_text_color = $upsellType->setting['discount_badge_text_color'];
                                                endif;
                                            ?>
                                             <a href="#" class="buttoncolor colorpicker" data-id="discount_badge_text_color" style="background-color:<?php echo e($discount_badge_text_color); ?>;">
                                             </a>
                                             <input value="<?php echo e($discount_badge_text_color); ?>" type="hidden" name="discount_badge_text_color">
                                             <p>Discount Badge Text Color</p>
                                          </div>
                                          <div class="f_input_color mt-3">
                                            <?php
                                                if(isset($upsell)):
                                                    $discount_badge_background = $upsell['setting']['discount_badge_background'];
                                                else:
                                                    $discount_badge_background = $upsellType->setting['discount_badge_background'];
                                                endif;
                                            ?>
                                             <a href="#" class="buttoncolor colorpicker" data-id="discount_badge_background" style="background-color: <?php echo e($discount_badge_background); ?>;">
                                             </a>
                                             <input value="<?php echo e($discount_badge_background); ?>" type="hidden" name="discount_badge_background">
                                             <p>Discount Badge Background</p>
                                          </div>
                                          <div class="f_input_color mt-3">
                                            <?php
                                                if(isset($upsell)):
                                                    $background_color = $upsell['setting']['background_color'];
                                                else:
                                                    $background_color = $upsellType->setting['background_color'];
                                                endif;
                                            ?>
                                             <a href="#" class="buttoncolor colorpicker" data-id="background_color" style="background-color: <?php echo e($background_color); ?>;">
                                             </a>
                                             <input value="<?php echo e($background_color); ?>" type="hidden" name="background_color">
                                             <p>Background Color</p>
                                          </div>
                                          <div class="f_input_color mt-3">
                                            <?php
                                                if(isset($upsell)):
                                                    $hover_background_color = $upsell['setting']['hover_background_color'];
                                                else:
                                                    $hover_background_color = $upsellType->setting['hover_background_color'];
                                                endif;
                                            ?>
                                             <a href="#" class="buttoncolor colorpicker" data-id="hover_background_color" style="background-color:<?php echo e($hover_background_color); ?>;">
                                             </a>
                                             <input value="<?php echo e($hover_background_color); ?>" type="hidden" name="hover_background_color">
                                             <p>Background Hover Color</p>
                                          </div>
                                          <div class="f_input_color mt-3">
                                            <?php
                                                if(isset($upsell)):
                                                    $container_background_color = $upsell['setting']['container_background_color'];
                                                else:
                                                    $container_background_color = $upsellType->setting['container_background_color'];
                                                endif;
                                            ?>
                                             <a href="#" class="buttoncolor colorpicker" data-id="container_background_color" style="background-color:<?php echo e($container_background_color); ?>;">
                                             </a>
                                             <input value="<?php echo e($container_background_color); ?>" type="hidden" name="container_background_color">
                                             <p>Container Background</p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="design_preview">
                                    <div class="live_p">
                                       <h2 class="volume_discount_heading_style"><?php echo e($upsellType->setting['volume_discount_heading']); ?></h2>
                                       <div class="volum_bg volum_bg1">
                                          <div class="volume_img">
                                             <img src="<?php echo e(asset('assets')); ?>/img/bag.png" alt="bag">
                                          </div>
                                          <div class="volume_head">
                                             <h3 class="quantity_color_style">2 Quantities</h3>
                                             <h4 class="best_deal_color_style">Best Deal</h4>
                                          </div>
                                          <div class="volume_dis">
                                             <h5 class="discount_badge_text_style discount_badge_background_style">10% Off</h5>
                                          </div>
                                          <div class="disc_price">
                                             <h2 class="discount_total_price_style"><?php echo e($currency); ?>19.99</h2>
                                             <p class="original_total_price_style"><?php echo e($currency); ?>29.99</p>
                                          </div>
                                       </div>
                                       <div class="volum_bg volume_best volum_bg2">
                                          <div class="volume_img">
                                             <img src="<?php echo e(asset('assets')); ?>/img/bag.png" alt="bag">
                                          </div>
                                          <div class="volume_head">
                                             <h3 class="quantity_color_style">3 Quantities</h3>
                                             <h4 class="best_deal_color_style">Best Deal</h4>
                                          </div>
                                          <div class="volume_dis">
                                             <h5 class="discount_badge_text_style discount_badge_background_style">20% Off</h5>
                                          </div>
                                          <div class="disc_price">
                                             <h2 class="discount_total_price_style"><?php echo e($currency); ?>19.99</h2>
                                             <p class="original_total_price_style"><?php echo e($currency); ?>39.99</p>
                                          </div>
                                       </div>
                                       <div class="volum_bg volum_bg3">
                                          <div class="volume_img">
                                             <img src="<?php echo e(asset('assets')); ?>/img/bag.png" alt="bag">
                                          </div>
                                          <div class="volume_head">
                                             <h3 class="quantity_color_style">5 Quantities</h3>
                                             <h4 class="best_deal_color_style">Best Deal</h4>
                                          </div>
                                          <div class="volume_dis">
                                             <h5 class="discount_badge_text_style discount_badge_background_style">30% Off</h5>
                                          </div>
                                          <div class="disc_price">
                                             <h2 class="discount_total_price_style"><?php echo e($currency); ?>19.99</h2>
                                             <p class="original_total_price_style"><?php echo e($currency); ?>49.99</p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <!-----------------Tab-2-Close----------------->
                  <div id="menu-fbt-video" class="tab-pane fade p-0"><br><div class="container-fluid">
                        	<div class="container">
                             <div class="row">
                              <div class="col-md-12">
                                 <iframe width="100%" height="515" src="https://www.youtube.com/embed/U_MkoqnmBWM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                              </div>
                           </div>
                        </div>
                        </div>
                    </div>
               </div>
            </form>
            </div>
         </div>
      </div>
   </div>
</div>
<!------------modal--------------->
<?php echo $__env->make('includes.components.pickProductModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.pages.volume_discount',[ "setting" => $upsellType->setting ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.shopify-app.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/volume_discount.blade.php ENDPATH**/ ?>