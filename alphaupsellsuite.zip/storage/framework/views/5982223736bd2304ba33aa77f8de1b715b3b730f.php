<div class="modal fade" id="centralModalSm3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
   aria-hidden="true">
   <!-- Change class .modal-sm to change the size of the modal -->
   <form class="template-<?php echo e($upsellTemplateId); ?>">
      <div class="modal-dialog modal-sm m_1_w" role="document">
         <div class="modal-content modal_1_show" style="height: 100vh;">
            <div class="modal-header">
               <h4 class="modal-title w-100 m_head_h">Customize Your Template</h4>
               <button type="button" class="close m1_close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body m_1_body">
               <div class="container">
                  <div class="col-md-12 popup_page">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="design_input">
                              <h3>Title</h3>
                              <p class="h_input">
                                 <label>Heading</label><br>
                                 <input type="text" placeholder="Thank You For Placing Order With Us" name="alpha_t3_heading" value= 
                                    <?php if(isset($upsell)): ?>
                                       "<?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t3_heading'] : $setting['top_heading']); ?>"
                                    <?php else: ?>
                                       "<?php echo e($setting['top_heading']); ?>"
                                    <?php endif; ?>
                                 />    
                              </p>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Font Family</label><br>
                                       <select name="alpha_t3_heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>" 
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['alpha_t3_heading_font_family']  == $family ? "selected":""); ?>   
                                                   <?php else: ?>    
                                                       <?php echo e($setting['top_heading_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($setting['top_heading_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?> 
                                             >
                                                <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Font Size</label><br>
                                       <input type="number" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_heading_font_size']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['top_heading_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['top_heading_font_size']); ?>"
                                          <?php endif; ?> 
                                       name="alpha_t3_heading_font_size">    
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_heading_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['top_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['top_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_heading_color" value=
                                           <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_heading_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['top_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['top_heading_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Heading Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_cross_icon_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_cross_icon_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cross_icon_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_cross_icon_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_cross_icon_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cross_icon_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Icon Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_cross_icon_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_cross_icon_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cross_icon_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden"  name="alpha_t3_cross_icon_bg_color"  value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_cross_icon_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cross_icon_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Icon Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Cart Product</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_cart_item_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_cart_item_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_product_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_product_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_cart_item_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_cart_item_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_product_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_product_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_cart_item_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_cart_item_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_product_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_product_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_cart_item_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_cart_item_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_product_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_product_border_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Border Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_cart_item_price_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_cart_item_price_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_product_price_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_product_price_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_cart_item_price_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_cart_item_price_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_product_price_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_product_price_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Price Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Countdown For Sales Timer</h3>
                              <div class="custom-control custom-checkbox">
                                 <input type="checkbox" value="1" class="custom-control-input" name="alpha_t3_timer" id="alpha_t3_timer" 
                                     <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          <?php echo e($upsell->setting['alpha_t3_timer'] ? "checked" : ""); ?>

                                       <?php else: ?>    
                                          <?php echo e($setting['offer_time_limit'] ? "checked":""); ?>

                                       <?php endif; ?>
                                    <?php else: ?>
                                       <?php echo e($setting['offer_time_limit'] ? "checked":""); ?>

                                    <?php endif; ?>
                                 >
                                 <label class="custom-control-label" for="alpha_t3_timer">Add a Time Limit To The Offer</label>
                              </div>
                              <p class="h_input">
                                 <label>Heading</label><br>
                                 <input type="text" placeholder="You May Be Interested In..." name="alpha_t3_r_product_heading" value=
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          "<?php echo e($upsell->setting['alpha_t3_r_product_heading']); ?>"    
                                       <?php else: ?>    
                                          "<?php echo e($setting['offer_heading']); ?>" 
                                       <?php endif; ?>
                                    <?php else: ?>
                                    "<?php echo e($setting['offer_heading']); ?>" 
                                    <?php endif; ?>
                                 />    
                              </p>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Heading Font Family</label><br>
                                       <select name="alpha_t3_r_product_heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>" 
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['alpha_t3_r_product_heading_font_family']  == $family ? "selected":""); ?>   
                                                   <?php else: ?>    
                                                      <?php echo e($setting['offer_heading_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($setting['offer_heading_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?>
                                             >
                                                <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Heading Font Size</label><br>
                                       <input type="number" min="1" name="alpha_t3_r_product_heading_font_size" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_r_product_heading_font_size']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['offer_heading_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['offer_heading_font_size']); ?>"
                                          <?php endif; ?> 
                                       />    
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Timer Duration In Minutes</label><br>
                                       <input type="number" name="alpha_t3_timer_duration" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_timer_duration']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['time_duration_minutes']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_duration_minutes']); ?>"
                                          <?php endif; ?>
                                       >    
                                    </p>
                                    <p class="f_input">
                                       <label>Timer Text</label><br>
                                       <input type="text" placeholder="Ends Soon:" name="alpha_t3_timer_heaading" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_timer_heaading']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['time_offer_heading']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_offer_heading']); ?>"
                                          <?php endif; ?> 
                                       />    	  
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Font Family</label><br>
                                       <select name="alpha_t3_timer_heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>" 
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['alpha_t3_timer_heading_font_family']  == $family ? "selected":""); ?>   
                                                   <?php else: ?>    
                                                      <?php echo e($setting['time_offer_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($setting['time_offer_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?>
                                             >
                                                   <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Font Size</label><br>
                                       <input type="number" name="alpha_t3_timer_heading_font_size" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_timer_heading_font_size']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['time_offer_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['time_offer_font_size']); ?>"
                                          <?php endif; ?>
                                       />    
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_r_product_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_r_product_heading_color']); ?>;"    
                                             <?php else: ?>    
                                                 "background-color:<?php echo e($setting['offer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                              "background-color:<?php echo e($setting['offer_heading_color']); ?>;" 
                                          <?php endif; ?>
                                      >
                                       </a>
                                       <input type="hidden" name="alpha_t3_r_product_heading_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_r_product_heading_color']); ?>"    
                                             <?php else: ?>    
                                                 "<?php echo e($setting['offer_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                              "<?php echo e($setting['offer_heading_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Heading Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_timer_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_timer_heading_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_timer_heading_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_timer_heading_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_heading_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Heading Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_timer_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_timer_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_timer_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_timer_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_timer_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_timer_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_timer_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_timer_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Product</h3>
                              <p class="h_input">
                                 <label>Button Text</label><br>
                                 <input type="text" placeholder="
                                     <?php if(isset($upsell)): ?>
                                                      <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t3_atc_btn'] : $setting['add_to_cart_text']); ?>

                                                   <?php else: ?>
                                                      <?php echo e($setting['add_to_cart_text']); ?>

                                                   <?php endif; ?>
                                 " name="alpha_t3_atc_btn" value=
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          "<?php echo e($upsell->setting['alpha_t3_atc_btn']); ?>;"    
                                       <?php else: ?>    
                                          "<?php echo e($setting['add_to_cart_text']); ?>"
                                       <?php endif; ?>
                                    <?php else: ?>
                                       "<?php echo e($setting['add_to_cart_text']); ?>" 
                                    <?php endif; ?>
                                 />
                              </p>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_atc_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_atc_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_atc_btn_bg_color" value=
                                           <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_atc_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Button Background Color</p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_atc_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_atc_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_atc_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_atc_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Button Text Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_price_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_price_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['Original_price_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['Original_price_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_price_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_price_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['Original_price_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['Original_price_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Original Price Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_dicount_price_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_dicount_price_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['discount_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_dicount_price_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_dicount_price_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['discount_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Discount Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_dicount_price_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_dicount_price_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['discount_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_dicount_price_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_dicount_price_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['discount_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Discount Text Color</p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_upsell_product_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_upsell_product_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['product_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['product_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_upsell_product_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_upsell_product_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['product_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['product_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Full Background Color</p>
                                    </div>
                                 </div>
                              </div>
                              <h3 class="mt-4">Translation</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Checkout Button</label><br>
                                       <input type="text" placeholder="Checkout" name="alpha_t3_checkout_btn" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_checkout_btn']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['checkout_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['checkout_button_text']); ?>"
                                          <?php endif; ?> 
                                       />
                                    </p>
                                    <p class="f_input">
                                       <label>No Thanks Button</label><br>
                                       <input type="text" placeholder="No Thanks" name="alpha_t3_no_thanks_btn" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_no_thanks_btn']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['no_thanks_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['no_thanks_button_text']); ?>"
                                          <?php endif; ?>
                                       />
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_checkout_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_checkout_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_checkout_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_checkout_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_no_thanks_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_no_thanks_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_no_thanks_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_no_thanks_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_checkout_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_checkout_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_checkout_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_checkout_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Text Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_no_thanks_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_no_thanks_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_no_thanks_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_no_thanks_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Text Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_checkout_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_checkout_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_checkout_border_color" value=
                                           <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_checkout_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_border_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Border Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t3_no_thanks_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t3_no_thanks_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t3_no_thanks_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t3_no_thanks_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_border_color']); ?>" 
                                          <?php endif; ?>
                                        />
                                       <p>No,Thanks Border Color </p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="design_p_inpage pt-2">
                              <!-------Modal content------->
                              <div class="modal-content modal_1 alpha_atc_t_3">
                                 <div class="modal_1_head">
                                    <h2>
                                    
                                       <p class="alpha_t3_heading" style="font-weight: bold !important;">
                                       <p class="t3-icon-template-3">&#10003;</p>

                                       
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                <?php echo e($upsell->setting['alpha_t3_heading']); ?>    
                                             <?php else: ?>   
                                                <?php echo e($setting['top_heading']); ?>

                                             <?php endif; ?>
                                          <?php else: ?>
                                             <?php echo e($setting['top_heading']); ?>

                                          <?php endif; ?>
                                       </p> 
                                     
                                       <span class="close alpha_close_model_t3" id="myModal">×</span>
                                    </h2>
                                 </div>
                                 <div class="modal_1_body">
                                    <div class="m_1_bg alpha_t3_cart_item">
                                       <div class="m_1_img">
                                          <img src="<?php echo e(asset('assets')); ?>/img/m-1-1.jpg" alt="shoes">
                                       </div>
                                       <div class="m_1_head">
                                          <h3>Elegant High Heels</h3>
                                          <p>(<span class="alpha_t3_cart_item_price"><?php echo e($currency); ?>34.99</span>)</p>
                                       </div>
                                       <div class="m_1_head_btn">
                                          <button type="button" class="m_1_top_btn_2 alpha_t3_checkout_btn">
                                             <?php if(isset($upsell)): ?>
                                                <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t3_checkout_btn'] : $setting['checkout_button_text']); ?>

                                             <?php else: ?>
                                                <?php echo e($setting['checkout_button_text']); ?>

                                             <?php endif; ?>
                                          </button>
                                       </div>
                                    </div>
                                    <div class="b_timer_shoe">
                                       <div class="b_timer_head_shoe">
                                          <h2 class="alpha_t3_r_product_heading">
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   <?php echo e($upsell->setting['alpha_t3_r_product_heading']); ?>    
                                                <?php else: ?>   
                                                   <?php echo e($setting['offer_heading']); ?>

                                                <?php endif; ?>
                                             <?php else: ?>
                                                <?php echo e($setting['offer_heading']); ?>

                                             <?php endif; ?>
                                          </h2>
                                       </div>
                                       <div class="m_2_time_shoe">
                                          <label class="alpha_t3_timer_heaading">
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   <?php echo e($upsell->setting['alpha_t3_timer_heaading']); ?>    
                                                <?php else: ?>   
                                                   <?php echo e($setting['time_offer_heading']); ?>

                                                <?php endif; ?>
                                             <?php else: ?>
                                                <?php echo e($setting['time_offer_heading']); ?>

                                             <?php endif; ?>
                                          </label>
                                          <input type="text" value=
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   "<?php echo e($upsell->setting['alpha_t3_timer_duration']); ?>"    
                                                <?php else: ?>   
                                                   "<?php echo e($setting['time_duration_minutes']); ?>"
                                                <?php endif; ?>
                                             <?php else: ?>
                                                "<?php echo e($setting['time_duration_minutes']); ?>"
                                             <?php endif; ?>
                                          class="alpha_t3_timer_duration alpha_t3_timer" readonly>:<input type="text" class="alpha_t3_timer" value="00" readonly>
                                       </div>
                                    </div>
                                    <div class="product_imgs">
                                       <div class="m_b_img_main">
                                          <div class="m_b_img">
                                             <div class="m_b_img_l">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-1-2.webp" alt="shoes">
                                             </div>
                                             <div class="m_b_img_r">
                                                <h3>Women Pumps Comfort High Heels</h3>
                                                <p><?php echo e($currency); ?>24.95 <span>20%Off</span></p>
                                                <form>
                                                   <select>
                                                      <option>Yellow</option>
                                                      <option>Black</option>
                                                   </select>
                                                   <select>
                                                      <option>24</option>
                                                      <option>32</option>
                                                   </select>
                                                </form>
                                                <button type="button" class="m_b_btn alpha_t3_atc_btn">
                                                    <?php if(isset($upsell)): ?>
                                                      <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t3_atc_btn'] : $setting['add_to_cart_text']); ?>

                                                   <?php else: ?>
                                                      <?php echo e($setting['add_to_cart_text']); ?>

                                                   <?php endif; ?>
                                                </button>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="m_b_img_main">
                                          <div class="m_b_img">
                                             <div class="m_b_img_l">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-1-3.webp" alt="shoes">
                                             </div>
                                             <div class="m_b_img_r">
                                                <h3>Women Pumps Comfort High Heels</h3>
                                                <p><?php echo e($currency); ?>24.95 <span>20%Off</span></p>
                                                <form>
                                                   <select>
                                                      <option>Black</option>
                                                      <option>Yellow</option>
                                                   </select>
                                                   <select>
                                                      <option>24</option>
                                                      <option>32</option>
                                                   </select>
                                                </form>
                                                <button type="button" class="m_b_btn alpha_t3_atc_btn">
                                                   <?php if(isset($upsell)): ?>
                                                      <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t3_atc_btn'] : $setting['add_to_cart_text']); ?>

                                                   <?php else: ?>
                                                      <?php echo e($setting['add_to_cart_text']); ?>

                                                   <?php endif; ?>
                                                </button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="product_imgs">
                                       <div class="m_b_img_main">
                                          <div class="m_b_img">
                                             <div class="m_b_img_l">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-1-4.jpg" alt="shoes">
                                             </div>
                                             <div class="m_b_img_r">
                                                <h3>Women Pumps Comfort High Heels</h3>
                                                <p><?php echo e($currency); ?>24.95 <span>20%Off</span></p>
                                                <form>
                                                   <select>
                                                      <option>Red</option>
                                                      <option>Black</option>
                                                   </select>
                                                   <select>
                                                      <option>24</option>
                                                      <option>32</option>
                                                   </select>
                                                </form>
                                                <button type="button" class="m_b_btn alpha_t3_atc_btn">
                                                    <?php if(isset($upsell)): ?>
                                                      <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t3_atc_btn'] : $setting['add_to_cart_text']); ?>

                                                   <?php else: ?>
                                                      <?php echo e($setting['add_to_cart_text']); ?>

                                                   <?php endif; ?>
                                                </button>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="m_b_img_main">
                                          <div class="m_b_img">
                                             <div class="m_b_img_l">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-1-5.jpg" alt="shoes">
                                             </div>
                                             <div class="m_b_img_r">
                                                <h3>Women Pumps Comfort High Heels</h3>
                                                <p><?php echo e($currency); ?>24.95 <span>20%Off</span></p>
                                                <form>
                                                <select>
                                                   <option>White</option>
                                                   <option>Yellow</option>
                                                </select>
                                                <select>
                                                   <option>24</option>
                                                   <option>32</option>
                                                </select>
                                                <button type="button" class="m_b_btn alpha_t3_atc_btn">
                                                    <?php if(isset($upsell)): ?>
                                                      <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t3_atc_btn'] : $setting['add_to_cart_text']); ?>

                                                   <?php else: ?>
                                                      <?php echo e($setting['add_to_cart_text']); ?>

                                                   <?php endif; ?>
                                                </button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="modal_1_footer">
                                    <button type="button" class="thnx_btn">
                                       <?php if(isset($upsell)): ?>
                                          <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t3_no_thanks_btn'] : $setting['no_thanks_button_text']); ?>

                                       <?php else: ?>
                                          <?php echo e($setting['no_thanks_button_text']); ?>

                                       <?php endif; ?>
                                    </button>
                                    <button type="button" class="m_1_top_btn_2 alpha_t3_checkout_btn">
                                       <?php if(isset($upsell)): ?>
                                          <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t3_checkout_btn'] : $setting['checkout_button_text']); ?>

                                       <?php else: ?>
                                          <?php echo e($setting['checkout_button_text']); ?>

                                       <?php endif; ?>
                                    </button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="cancel" data-dismiss="modal">Cancel</button>
               <?php if(isset($upsell)): ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save update_setting">Save Changes</button>
               <?php else: ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save save_setting">Save Changes</button>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </form>
</div><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/includes/components/add_to_cart_template3.blade.php ENDPATH**/ ?>