<?php

namespace App\Http\Controllers;

class SetupController extends Controller
{



}
