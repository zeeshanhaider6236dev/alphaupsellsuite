<div class="container-fluid">
    <div class="container">
        <div class="col-md-12 top">
            <a href="<?php echo e(route('home').'?tab=menu1'); ?>"><i class="fa fa-angle-left"></i>Offers</a>
            <div class="row">
                <div class="col-md-7 top_left">
                    <?php if(isset($upsell)): ?>
                        <h3>Update an offer</h3>
                    <?php else: ?>
                        <h3>Create an offer</h3>
                    <?php endif; ?>
                </div>
                <div class="col-md-5 top_right">
                    <a href="<?php echo e(route('home').'?tab=menu1'); ?>" class="cancel">Cancel</a>
                    <?php if(isset($upsell)): ?>
                        <button type="button" class="save updateUpsell">Update</button>
                    <?php else: ?>
                        <button type="button" class="save saveUpsell">Save</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>  
    </div>
</div><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/includes/upsell_header.blade.php ENDPATH**/ ?>