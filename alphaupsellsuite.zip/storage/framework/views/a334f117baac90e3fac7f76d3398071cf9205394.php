<!-----------Modal-1---------->
<div class="modal fade" id="centralModalSm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
   aria-hidden="true">
   <!-- Change class .modal-sm to change the size of the modal -->
   <form class="template-<?php echo e($upsellTemplateId); ?>">
      <div class="modal-dialog modal-sm m_1_w" role="document" style="height: 100vh !important;">
         <div class="modal-content modal_1_show" style="height: 100vh !important;">
            <div class="modal-header">
               <h4 class="modal-title w-100 m_head_h">Customize Your Template</h4>
               <button type="button" class="close m1_close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body m_1_body">
               <div class="container">
                  <div class="col-md-12 popup_page">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="design_input">
                              <h3>Title</h3>
                              <p class="h_input">
                                 <label>Heading</label><br>
                                 <input type="text" value=
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          "<?php echo e($upsell->setting['add_to_cart_heading']); ?>"
                                       <?php else: ?>
                                          "<?php echo e($setting['add_to_cart_heading']); ?>"
                                       <?php endif; ?>
                                    <?php else: ?>
                                    "<?php echo e($setting['add_to_cart_heading']); ?>"
                                    <?php endif; ?>
                                    name="add_to_cart_heading"
                                 />
                              </p>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Font Family</label><br>
                                       <select name="heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>"
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['heading_font_family']  == $family ? "selected":""); ?>

                                                   <?php else: ?>
                                                      <?php echo e($setting['heading_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                   <?php echo e($setting['heading_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?>
                                             >
                                                <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Font Size</label><br>
                                       <input type="number" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['heading_font_size']); ?>"
                                             <?php else: ?>
                                                "<?php echo e($setting['heading_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['heading_font_size']); ?>"
                                          <?php endif; ?>
                                        name="heading_font_size">
                                    </p>
                                    <p class="f_input">
                                       <label>Total Price</label><br>
                                       <input type="text" name="total_price_text" value="Total:" />
                                    </p>

                                    <p class="f_input">
                                       <label>Text Align</label><br>
                                       <select name="heading_align">
                                          <option value="Left"
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   <?php echo e($upsell->setting['heading_align'] == 'Left'? 'selected':''); ?>

                                                <?php else: ?>
                                                   <?php echo e($setting['heading_align'] == 'Left'? 'selected':''); ?>

                                                <?php endif; ?>
                                             <?php else: ?>
                                                <?php echo e($setting['heading_align'] == 'Left'? 'selected':''); ?>

                                             <?php endif; ?>
                                          >Left</option>
                                          <option value="Center"
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   <?php echo e($upsell->setting['heading_align'] == 'Center'? 'selected':''); ?>

                                                <?php else: ?>
                                                   <?php echo e($setting['heading_align'] == 'Center'? 'selected':''); ?>

                                                <?php endif; ?>
                                             <?php else: ?>
                                                <?php echo e($setting['heading_align'] == 'Center'? 'selected':''); ?>

                                             <?php endif; ?>
                                          >Center</option>
                                          <option value="Right"
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   <?php echo e($upsell->setting['heading_align'] == 'Right'? 'selected':''); ?>

                                                <?php else: ?>
                                                   <?php echo e($setting['heading_align'] == 'Right'? 'selected':''); ?>

                                                <?php endif; ?>
                                             <?php else: ?>
                                                <?php echo e($setting['heading_align'] == 'Right'? 'selected':''); ?>

                                             <?php endif; ?>
                                          >Right</option>
                                       </select>
                                    </p>
                                 </div>
                              </div>
                              <h3>Color</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha-m-1-heading-color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha-m-1-heading-color']); ?>;"
                                             <?php else: ?>
                                                "background-color: <?php echo e($setting['heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color: <?php echo e($setting['heading_color']); ?>;"
                                          <?php endif; ?>
                                       name="alpha-m-1-heading-color">
                                       </a>
                                       <input type="hidden" name="alpha-m-1-heading-color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha-m-1-heading-color']); ?>"
                                             <?php else: ?>
                                                "<?php echo e($setting['heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['heading_color']); ?>"
                                          <?php endif; ?>
                                       />

                                       <p>Heading Color </p>
                                    </div>

                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_heading_bg_color_m1" class="buttoncolor colorpicker" name="back_ground_color" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color: <?php echo e($upsell->setting['alpha_heading_bg_color_m1']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['heading_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['heading_background_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_heading_bg_color_m1" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_heading_bg_color_m1']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['heading_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['heading_background_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>Background Color </p>
                                    </div>

                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">

                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_cross_icom_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_cross_icom_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['cross_icon_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_color']); ?>;"
                                          <?php endif; ?>
                                        name="cross_icon_color">
                                       </a>
                                       <input type="hidden" name="alpha_cross_icom_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_cross_icom_color']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['cross_icon_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>Icon Color </p>
                                    </div>



                                    <div class="f_input_color">
                                       <a href="#" data-id="text-color-price-total" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_cross_icom_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['cross_icon_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_color']); ?>;"
                                          <?php endif; ?>
                                        name="cross_icon_color">
                                       </a>
                                       <input type="hidden" name="text-color-price-total" value=
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             "<?php echo e($upsell->setting['alpha_cross_icom_color']); ?>"
                                          <?php else: ?>
                                            "<?php echo e($setting['cross_icon_color']); ?>"
                                          <?php endif; ?>
                                       <?php else: ?>
                                          "<?php echo e($setting['cross_icon_color']); ?>"
                                       <?php endif; ?>
                                       />
                                       <p> Total Color </p>
                                    </div>

                                 </div>


                              </div>

                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="price-color-figure" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['price-color-figure']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['price-color-figure']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['price-color-figure']); ?>;"
                                          <?php endif; ?>
                                        name="cross_icon_color">
                                       </a>
                                       <input type="hidden" name="price-color-figure" value=
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             "<?php echo e($upsell->setting['price-color-figure']); ?>"
                                          <?php else: ?>
                                            "<?php echo e($setting['price-color-figure']); ?>"
                                          <?php endif; ?>
                                       <?php else: ?>
                                          "<?php echo e($setting['price-color-figure']); ?>"
                                       <?php endif; ?>
                                       />
                                       <p> Price Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Countdown for Sales Timer</h3>
                              <div class="custom-control custom-checkbox">
                                 <input type="checkbox" value="1" class="custom-control-input" id="defaultCheckedDisabled2" name="offer_time_limit"
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          <?php echo e($upsell->setting['offer_time_limit'] ? "checked" : ""); ?>

                                       <?php else: ?>
                                          <?php echo e($setting['offer_time_limit'] ? "checked" : ""); ?>

                                       <?php endif; ?>
                                    <?php else: ?>
                                       <?php echo e($setting['offer_time_limit'] ? "checked" : ""); ?>

                                    <?php endif; ?>
                                 />
                                 <label class="custom-control-label" for="defaultCheckedDisabled2">
                                    Add a Time Limit To The Offer
                                 </label>
                              </div>
                              <p class="h_input">
                                 <label>Heading</label><br>
                                 <input type="text" value=
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          "<?php echo e($upsell->setting['time_offer_heading']); ?>"
                                       <?php else: ?>
                                          "<?php echo e($setting['time_offer_heading']); ?>"
                                       <?php endif; ?>
                                    <?php else: ?>
                                    "<?php echo e($setting['time_offer_heading']); ?>"
                                    <?php endif; ?>
                                 name="time_offer_heading" />
                              </p>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Heading Font Family</label><br>
                                       <select name="offer_heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>"
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['offer_heading_font_family']  == $family ? "selected":""); ?>

                                                   <?php else: ?>
                                                      <?php echo e($setting['offer_heading_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                   <?php echo e($setting['offer_heading_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?>
                                             >
                                                <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Heading Font Size</label><br>
                                       <input type="number" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['offer_heading_font_size']); ?>"
                                             <?php else: ?>
                                                "<?php echo e($setting['offer_heading_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['offer_heading_font_size']); ?>"
                                          <?php endif; ?>
                                          name="offer_heading_font_size">
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Timer Duration In Minutes</label><br>
                                       <input type="number" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['time_duration_minutes']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['time_duration_minutes']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_duration_minutes']); ?>"
                                          <?php endif; ?>
                                         name="time_duration_minutes">
                                    </p>
                                    <p class="f_input">
                                       <label>Timer Text</label><br>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['timer_text']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['timer_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['timer_text']); ?>"
                                          <?php endif; ?>
                                         name="timer_text">
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="time_offer_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['time_offer_heading_color']); ?>;"
                                             <?php else: ?>
                                              "background-color:<?php echo e($setting['time_offer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "background-color:<?php echo e($setting['time_offer_heading_color']); ?>;"
                                          <?php endif; ?>
                                        >
                                       </a>
                                       <input type="hidden" name="time_offer_heading_color" value =
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['time_offer_heading_color']); ?>"
                                             <?php else: ?>
                                                "<?php echo e($setting['time_offer_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_offer_heading_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>Heading Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="timer_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['timer_heading_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['timer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_heading_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden"  name="timer_heading_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['timer_heading_color']); ?> "
                                             <?php else: ?>
                                                "<?php echo e($setting['timer_heading_color']); ?> "
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_heading_color']); ?> "
                                          <?php endif; ?>
                                       />
                                       <p>Timer Heading Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="timer_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['timer_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['timer_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden"  name="timer_color" value =
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['timer_color']); ?> "
                                             <?php else: ?>
                                               "<?php echo e($setting['timer_color']); ?> "
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_color']); ?> "
                                          <?php endif; ?>
                                       />
                                       <p>Timer Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Product</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Add To Cart Button</label><br>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['add_to_cart_text']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['add_to_cart_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['add_to_cart_text']); ?>"
                                          <?php endif; ?>
                                       name="add_to_cart_text">
                                    </p>
                                    <div class="f_input_color">
                                       <label></label><br>
                                       <a href="#" data-id="alpha_original_price_color_m1" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_original_price_color_m1']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['Original_price_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['Original_price_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_original_price_color_m1" value =
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_original_price_color_m1']); ?>"
                                             <?php else: ?>
                                                "<?php echo e($setting['Original_price_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['Original_price_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>Original Price Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="button_background_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['button_background_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['button_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['button_background_color']); ?>;"
                                          <?php endif; ?>
                                        >
                                       </a>
                                       <input type="hidden" name="button_background_color" value =
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['button_background_color']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['button_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['button_background_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>Button Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="discount_background_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['discount_background_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['discount_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_background_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="discount_background_color" value =
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['discount_background_color']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['discount_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_background_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>Discount Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="button_text_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['button_text_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['button_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['button_text_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="button_text_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['button_text_color']); ?>"
                                             <?php else: ?>
                                                "<?php echo e($setting['button_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['button_text_color']); ?>"
                                          <?php endif; ?>
                                          />
                                       <p>Button Text Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="discount_text_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['discount_text_color']); ?>;"
                                             <?php else: ?>
                                                "background-color:<?php echo e($setting['discount_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_text_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="discount_text_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['discount_text_color']); ?>"
                                             <?php else: ?>
                                                "<?php echo e($setting['discount_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_text_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>Discount Text Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3 class="mt-4">Translation</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Checkout Button</label><br>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['checkout_button_text']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['checkout_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['checkout_button_text']); ?>"
                                          <?php endif; ?>
                                        name="checkout_button_text">
                                    </p>
                                    <p class="f_input">
                                       <label>No Thanks Button</label><br>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['no_thanks_button_text']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['no_thanks_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['no_thanks_button_text']); ?>"
                                          <?php endif; ?>
                                        name="no_thanks_button_text">
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="checkout_background_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['checkout_background_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['checkout_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_background_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden"  name="checkout_background_color" value =
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['checkout_background_color']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['checkout_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_background_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="no_thanks_background_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['no_thanks_background_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="no_thanks_background_color" value =
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['no_thanks_background_color']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['no_thanks_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_background_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="checkout_text_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['checkout_text_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['checkout_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_text_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="checkout_text_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['checkout_text_color']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['checkout_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_text_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Text Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="no_thanks_text_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['no_thanks_text_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="no_thanks_text_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['no_thanks_text_color']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['no_thanks_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_text_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Text Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="checkout_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['checkout_border_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['checkout_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_border_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="checkout_border_color" value =
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['checkout_border_color']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['checkout_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_border_color']); ?>"
                                          <?php endif; ?>
                                        />
                                       <p>Checkout Border Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="no_thanks_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['no_thanks_border_color']); ?>;"
                                             <?php else: ?>
                                               "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;"
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="no_thanks_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['no_thanks_border_color']); ?>"
                                             <?php else: ?>
                                               "<?php echo e($setting['no_thanks_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_border_color']); ?>"
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Border Color </p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="design_p_inpage pt-2">
                              <!-------Modal content------->
                              <div class="modal-2 alpha_atc_m_2">
                                 <div class="modal_2_head">
                                    <i class="fa fa-check alpha_atc_heading_m1_check aus-tick-emoji" style="color: #f34d00 !important; background: none !important;"></i>
                                    <h2 class="add_to_cart_heading_m_1">
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             <?php echo e($upsell->setting['add_to_cart_heading']); ?>

                                          <?php else: ?>
                                             <?php echo e($setting['add_to_cart_heading']); ?>

                                          <?php endif; ?>
                                       <?php else: ?>
                                       <?php echo e($setting['add_to_cart_heading']); ?>

                                       <?php endif; ?>
                                    </h2>
                                    <span class="close alpha_close_model" id="myModal2">×</span>
                                 </div>
                                 <div class="modal_2_body">
                                    <div class="top_product">
                                       <div class="top_p_img">
                                          <img src="<?php echo e(asset('assets')); ?>/img/m-2-1.jpg" alt="dress">
                                       </div>
                                       <div class="top_p_detail">
                                          <h3>Shop Ethnic Outfits Online - Affordable <br> Women's Clothes..!!  </h3>
                                          <div class="total-price-container">
                                             <p class="total-price-text">Total:<p>
                                             <span class="aus-total-price-fig" style="font-size: 13px; font-weight: bold;"><?php echo e($currency); ?>39.95</span>
                                          </div>

                                          <!-- <table width="30%">
                                             <tbody>
                                                <tr>
                                                   <td>
                                                      <p>Color:</p>
                                                   </td>
                                                   <td>
                                                      <select>
                                                         <option>Blue</option>
                                                         <option>Black</option>
                                                         <option>Pink</option>
                                                      </select>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td>
                                                      <p>Size:</p>
                                                   </td>
                                                   <td>
                                                      <select>
                                                         <option>24</option>
                                                         <option>26</option>
                                                         <option>28</option>
                                                      </select>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td>
                                                      <p>Qty:</p>
                                                   </td>
                                                   <td>
                                                      <input type="number" min="1" value="1">
                                                   </td>
                                                </tr>
                                             </tbody>
                                          </table> -->
                                       </div>
                                    </div>
                                    <div class="b_timer">
                                       <div class="b_timer_head">
                                          <h2 class="b_timer_head_text">
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   <?php echo e($upsell->setting['time_offer_heading']); ?>

                                                <?php else: ?>
                                                   <?php echo e($setting['time_offer_heading']); ?>

                                                <?php endif; ?>
                                             <?php else: ?>
                                                <?php echo e($setting['time_offer_heading']); ?>

                                             <?php endif; ?>
                                          </h2>
                                       </div>
                                          <div class="m_2_time">
                                             <label class="alpha_m1_timer_label">
                                                <?php if(isset($upsell)): ?>
                                                   <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['timer_text'] : $setting['timer_text']); ?>

                                                <?php else: ?>
                                                   <?php echo e($setting['timer_text']); ?>

                                                <?php endif; ?>
                                             </label>
                                             <input type="text" class="offer_timer_m1_minutes" value=
                                                <?php if(isset($upsell)): ?>
                                                   <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['time_duration_minutes'] : $setting['time_duration_minutes']); ?>

                                                <?php else: ?>
                                                   <?php echo e($setting['time_duration_minutes']); ?>

                                                <?php endif; ?>
                                              readonly>:<input type="text" class="offer_timer_m1_seconds" value="00" readonly>
                                          </div>
                                    </div>
                                    <div class="m_2_products">
                                       <div class="m2_p_main">
                                          <div class="m2_p_box">
                                             <div class="m2_img">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-2-2.jpg" alt="dress">
                                             </div>
                                             <div class="m2_detail">
                                                <h4>Shop Ethnic Outfits Online Women's Clothes</h4>
                                                <p><?php echo e($currency); ?>49.99 <span>20%Off</span></p>
                                                <span>
                                                   <select>
                                                      <option>Blue</option>
                                                      <option>Black</option>
                                                      <option>Yellow</option>
                                                   </select>
                                                   <select>
                                                      <option>S</option>
                                                      <option>M</option>
                                                      <option>L</option>
                                                   </select>
                                                </span>
                                                <button type="button" class="alpha_m1_add_to_cart_btn">
                                                   <?php if(isset($upsell)): ?>
                                                      <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ?  $upsell->setting['add_to_cart_text']  :  $setting['add_to_cart_text']); ?>

                                                   <?php else: ?>
                                                   <?php echo e($setting['add_to_cart_text']); ?>

                                                   <?php endif; ?>
                                                </button>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="m2_p_main">
                                          <div class="m2_p_box">
                                             <div class="m2_img">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-2-3.jpg" alt="dress">
                                             </div>
                                             <div class="m2_detail">
                                                <h4>Shop Ethnic Outfits Online Women's Clothes</h4>
                                                <p><?php echo e($currency); ?>49.99 <span>20%Off</span></p>
                                                <span>
                                                   <select>
                                                      <option>White</option>
                                                      <option>Black</option>
                                                      <option>Yellow</option>
                                                   </select>
                                                   <select>
                                                      <option>S</option>
                                                      <option>M</option>
                                                      <option>L</option>
                                                   </select>
                                                </span>
                                                <button type="button" class="alpha_m1_add_to_cart_btn">
                                                   <?php if(isset($upsell)): ?>
                                                      <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ?  $upsell->setting['add_to_cart_text']  :  $setting['add_to_cart_text']); ?>

                                                   <?php else: ?>
                                                   <?php echo e($setting['add_to_cart_text']); ?>

                                                   <?php endif; ?>
                                                </button>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="m2_p_main">
                                          <div class="m2_p_box">
                                             <div class="m2_img">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-2-4.jpg" alt="dress">
                                             </div>
                                             <div class="m2_detail">
                                                <h4>Shop Ethnic Outfits Online Women's Clothes</h4>
                                                <p><?php echo e($currency); ?>49.99 <span>20%Off</span></p>
                                                <span>
                                                   <select>
                                                      <option>Blue</option>
                                                      <option>Black</option>
                                                      <option>Yellow</option>
                                                   </select>
                                                   <select>
                                                      <option>S</option>
                                                      <option>M</option>
                                                      <option>L</option>
                                                   </select>
                                                </span>
                                                <button type="button" class="alpha_m1_add_to_cart_btn">
                                                   <?php if(isset($upsell)): ?>
                                                      <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ?  $upsell->setting['add_to_cart_text']  :  $setting['add_to_cart_text']); ?>

                                                   <?php else: ?>
                                                      <?php echo e($setting['add_to_cart_text']); ?>

                                                   <?php endif; ?>
                                                </button>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="modal_2_footer">
                                    <button type="button" class="m_2_btn_2">
                                       <?php if(isset($upsell)): ?>
                                          <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ?  $upsell->setting['checkout_button_text']  :  $setting['checkout_button_text']); ?>

                                       <?php else: ?>
                                          <?php echo e($setting['checkout_button_text']); ?>

                                       <?php endif; ?>
                                    </button>
                                    <button type="button" class="m_2_btn">
                                       <?php if(isset($upsell)): ?>
                                          <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ?  $upsell->setting['no_thanks_button_text']  :  $setting['no_thanks_button_text']); ?>

                                       <?php else: ?>
                                          <?php echo e($setting['no_thanks_button_text']); ?>

                                       <?php endif; ?>
                                    </button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="cancel" data-dismiss="modal">Cancel</button>
               <?php if(isset($upsell)): ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save update_setting">Save Changes</button>
               <?php else: ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save save_setting">Save Changes</button>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </form>
</div>
<!-----------End Modal-1---------->
<?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/includes/components/add_to_cart_template1.blade.php ENDPATH**/ ?>