<!-----------Modal-5---------->
<div class="modal fade" id="centralModalSm5" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
   aria-hidden="true">
   <!-- Change class .modal-sm to change the size of the modal -->
   <form class="template-<?php echo e($upsellTemplateId); ?>">
      <div class="modal-dialog modal-sm m_1_w" role="document">
         <div class="modal-content modal_1_show" style="height: 100vh;">
            <div class="modal-header">
               <h4 class="modal-title w-100 m_head_h">Customize Your Template</h4>
               <button type="button" class="close m1_close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body m_1_body">
               <div class="container">
                  <div class="col-md-12 popup_page">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="design_input">
                              <h3>Countdown For Sales Timer</h3>
                              <div class="custom-control custom-checkbox">
                                 <input type="checkbox" value="1" class="custom-control-input" name="alpha_t5_time_limit_toggler" id="alpha_t5_time_limit_toggler" 
                                     <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          <?php echo e($upsell->setting['alpha_t5_time_limit_toggler'] ? "checked" : ""); ?>

                                       <?php else: ?>    
                                          <?php echo e($setting['offer_time_limit'] ? "checked":""); ?>

                                       <?php endif; ?>
                                    <?php else: ?>
                                       <?php echo e($setting['offer_time_limit'] ? "checked":""); ?>

                                    <?php endif; ?>                                 
                                 />
                                 <label class="custom-control-label" for="alpha_t5_time_limit_toggler">Add a Time Limit To The Offer</label>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Timer Duration In Minutes</label><br>
                                       <input type="number" name="alpha_t5_time_duration" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_time_duration']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['time_duration_minutes']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_duration_minutes']); ?>"
                                          <?php endif; ?>
                                       >
                                    </p>
                                    <p class="f_input">
                                       <label>Timer Text</label><br>
                                       <input type="text" placeholder="Don't miss our special deals:" name="alpha_t5_timer_heading" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_timer_heading']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['time_offer_heading']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_offer_heading']); ?>"
                                          <?php endif; ?>
                                       >
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Font Family</label><br>
                                       <select name="alpha_t5_timer_heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>" 
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['alpha_t5_timer_heading_font_family']  == $family ? "selected":""); ?>   
                                                   <?php else: ?>    
                                                      <?php echo e($setting['time_offer_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($setting['time_offer_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?>
                                             >
                                                <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Font Size</label><br>
                                       <input type="number" max="18" name="alpha_t5_timer_heading_font_size" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_timer_heading_font_size']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['time_offer_font_size']); ?>" 
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['time_offer_font_size']); ?>" 
                                          <?php endif; ?>
                                       >
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_time_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_time_heading_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_time_heading_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_time_heading_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_heading_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Heading Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_timer_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_timer_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_timer_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_timer_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_timer_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_timer_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_timer_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_timer_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_cross_icon_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_cross_icon_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cross_icon_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_cross_icon_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_cross_icon_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cross_icon_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Icon Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Cart Product</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_cart_product_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_cart_product_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_product_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_product_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       > 
                                       </a>
                                       <input type="hidden" name="alpha_t5_cart_product_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_cart_product_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_product_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_product_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_cart_produt_price_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_cart_produt_price_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_product_price_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_product_price_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_cart_produt_price_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_cart_produt_price_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_product_price_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_product_price_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Price Color</p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Product</h3>
                              <p class="h_input">
                                 <label>Button Text</label><br>
                                 <input type="text" placeholder="Add" name="alpha_t5_atc_btn" value=
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          "<?php echo e($upsell->setting['alpha_t5_atc_btn']); ?>"    
                                       <?php else: ?>    
                                          "<?php echo e($setting['add_to_cart_text']); ?>"
                                       <?php endif; ?>
                                    <?php else: ?>
                                       "<?php echo e($setting['add_to_cart_text']); ?>" 
                                    <?php endif; ?>
                                 >    
                              </p>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_atc_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_atc_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_atc_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_atc_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Button Background Color</p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_atc_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_atc_btn_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_atc_btn_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_atc_btn_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_border_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Button Border Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_atc_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_atc_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_atc_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_atc_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Button Text Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_price_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_price_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       "background-color:<?php echo e($setting['original_price_color']); ?>;">
                                       </a>
                                       <input type="hidden" name="alpha_t5_price_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_price_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['original_price_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['original_price_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Original Price Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_discount_price_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_discount_price_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['discount_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_discount_price_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_discount_price_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['discount_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Discount Background Color</p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_discount_price_color" class="buttoncolor  colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_discount_price_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['discount_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_discount_price_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_discount_price_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['discount_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Discount Text Color</p>
                                    </div>
                                 </div>
                              </div>
                              <h3 class="mt-4">Translation</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Checkout Button</label><br>
                                       <input type="text" placeholder="Continue To Checkout" name="alpha_t5_checkout_btn" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_checkout_btn']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_button_text']); ?>" 
                                          <?php endif; ?>
                                       >    
                                    </p>
                                    <p class="f_input">
                                       <label>No Thanks Button</label><br>
                                       <input type="text" placeholder="No Thanks" name="alpha_t5_no_thanks_btn" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_no_thanks_btn']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_button_text']); ?>" 
                                          <?php endif; ?>
                                       >    	  
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_checkout_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_checkout_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_checkout_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_checkout_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_no_thanks_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_no_thanks_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_no_thanks_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_no_thanks_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_checkout_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_checkout_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_checkout_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_checkout_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Text Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_no_thanks_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_no_thanks_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_no_thanks_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_no_thanks_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Text Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_checkout_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_checkout_btn_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_checkout_btn_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_checkout_btn_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_border_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Border Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t5_no_thanks_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t5_no_thanks_btn_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t5_no_thanks_btn_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t5_no_thanks_btn_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_border_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Border Color </p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="design_p_inpage pt-2">
                              <!-------Modal content------->
                              <div class="modal-content modal-3 alpha_atc_t_5">
                                 <div class="modal_3_head">
                                    <div>
                                       <span class="close t5_cross_icon" id="myModal4">×</span>
                                       <div class="b_timer3">
                                          <h4 class="alpha_t5_timer_heading">
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   <?php echo e($upsell->setting['alpha_t5_timer_heading']); ?>   
                                                <?php else: ?>    
                                                <?php echo e($setting['time_offer_heading']); ?>

                                                <?php endif; ?>
                                             <?php else: ?>
                                             <?php echo e($setting['time_offer_heading']); ?>

                                             <?php endif; ?>
                                          </h4>
                                          <div class="timer3 t5_timer_d">
                                             <input type="text" class="t5_timer alpha_t5_timer" value=
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      "<?php echo e($upsell->setting['alpha_t5_time_duration']); ?>"   
                                                   <?php else: ?>    
                                                   "<?php echo e($setting['time_duration_minutes']); ?>"
                                                   <?php endif; ?>
                                                <?php else: ?>
                                                "<?php echo e($setting['time_duration_minutes']); ?>"
                                                <?php endif; ?>
                                             ><input type="text" value="00" class="alpha_t5_timer">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="m_3_top">
                                    <div class="m_3_top_img" style="width: 6% !important">
                                    <i class="fas fa-check"></i>
                                       <!-- <img src="<?php echo e(asset('assets')); ?>/img/m-3-cart.png" alt="cart"> -->
                                    </div>
                                    <div class="m_3_top_price">
                                       <h4 style="font-weight: bold !important;"> Diagonal Stripe Card Wallet <span><?php echo e($currency); ?>99.95</span></h4>
                                    </div>
                                 </div>
                                 <div class="modal_3_body">
                                    <div class="m_3_p">
                                       <div class="m_3_p_img">
                                          <img src="<?php echo e(asset('assets')); ?>/img/m-3-1.png" alt="watch">
                                       </div>
                                       <div class="m_3_p_detail">
                                          <div class="m_3_name">
                                             <h3>
                                                CURREN MEN'S TOP QUALITY WATCH <br>(DIAL 4.6CM) - CUR 148
                                                <span>
                                                   <select>
                                                      <option>Brown</option>
                                                      <option>Black</option>
                                                   </select>
                                                   <input type="button" class="alpha_t5_atc_btn alpha_t5_atc_btn-or" value=
                                                      <?php if(isset($upsell)): ?>
                                                         <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                            "<?php echo e($upsell->setting['alpha_t5_atc_btn']); ?>"    
                                                         <?php else: ?>    
                                                            "<?php echo e($setting['add_to_cart_text']); ?>"
                                                         <?php endif; ?>
                                                      <?php else: ?>
                                                         "<?php echo e($setting['add_to_cart_text']); ?>" 
                                                      <?php endif; ?>
                                                   >
                                                </span>
                                             </h3>
                                             <p><?php echo e($currency); ?>99.95 <span>30%Off</span></p>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="m_3_p">
                                       <div class="m_3_p_img">
                                          <img src="<?php echo e(asset('assets')); ?>/img/m-3-2.jpg" alt="belt">
                                       </div>
                                       <div class="m_3_p_detail">
                                          <div class="m_3_name">
                                             <h3>
                                                CURREN MEN'S TOP QUALITY WATCH <br>(DIAL 4.6CM) - CUR 148
                                                <span>
                                                   <select>
                                                      <option>Brown</option>
                                                      <option>Black</option>
                                                   </select>
                                                   <input type="button" class="alpha_t5_atc_btn alpha_t5_atc_btn-or" value=
                                                      <?php if(isset($upsell)): ?>
                                                         <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                            "<?php echo e($upsell->setting['alpha_t5_atc_btn']); ?>"    
                                                         <?php else: ?>    
                                                            "<?php echo e($setting['add_to_cart_text']); ?>"
                                                         <?php endif; ?>
                                                      <?php else: ?>
                                                         "<?php echo e($setting['add_to_cart_text']); ?>" 
                                                      <?php endif; ?>
                                                   >
                                                </span>
                                             </h3>
                                             <p><?php echo e($currency); ?>99.95 <span>30%Off</span></p>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="m_3_p">
                                       <div class="m_3_p_img">
                                          <img src="<?php echo e(asset('assets')); ?>/img/m-3-3.jpg" alt="wallet">
                                       </div>
                                       <div class="m_3_p_detail">
                                          <div class="m_3_name">
                                             <h3>
                                                CURREN MEN'S TOP QUALITY WATCH <br>(DIAL 4.6CM) - CUR 148
                                                <span>
                                                   <select>
                                                      <option>Brown</option>
                                                      <option>Black</option>
                                                   </select>
                                                   <input type="button" class="alpha_t5_atc_btn alpha_t5_atc_btn-or " value=
                                                      <?php if(isset($upsell)): ?>
                                                         <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                            "<?php echo e($upsell->setting['alpha_t5_atc_btn']); ?>"    
                                                         <?php else: ?>    
                                                            "<?php echo e($setting['add_to_cart_text']); ?>"
                                                         <?php endif; ?>
                                                      <?php else: ?>
                                                         "<?php echo e($setting['add_to_cart_text']); ?>" 
                                                      <?php endif; ?>
                                                   >
                                                </span>
                                             </h3>
                                             <p><?php echo e($currency); ?>99.95 <span>30%Off</span></p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="modal_3_footer">
                                    <button type="button" class="m3_btn1 t5_checkout_btn">
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             <?php echo e($upsell->setting['alpha_t5_checkout_btn']); ?>    
                                          <?php else: ?>    
                                             <?php echo e($setting['checkout_button_text']); ?>

                                          <?php endif; ?>
                                       <?php else: ?>
                                          <?php echo e($setting['checkout_button_text']); ?> 
                                       <?php endif; ?>
                                    </button> 
                                    <button type="button" class="m3_btn2 t5_no_thanks_btn">
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             <?php echo e($upsell->setting['alpha_t5_no_thanks_btn']); ?>    
                                          <?php else: ?>    
                                             <?php echo e($setting['no_thanks_button_text']); ?>

                                          <?php endif; ?>
                                       <?php else: ?>
                                          <?php echo e($setting['no_thanks_button_text']); ?> 
                                       <?php endif; ?>
                                    </button> 
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="cancel" data-dismiss="modal">Cancel</button>
               <?php if(isset($upsell)): ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save update_setting">Save Changes</button>
               <?php else: ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save save_setting">Save Changes</button>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </form>
</div><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/includes/components/add_to_cart_template5.blade.php ENDPATH**/ ?>