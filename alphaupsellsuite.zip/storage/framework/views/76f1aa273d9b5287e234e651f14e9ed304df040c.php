<?php if($upsell->upsellType->name != 'Pre Purchase'): ?>
    <?php echo $__env->make(getSingleUpsellCss($upsell->upsellType->name), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make(getAtcSingleTemplateCss($upsell->setting['upsell_template_type']), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/upsell_designs/index_css.blade.php ENDPATH**/ ?>