<?php echo $msg ?>
