<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.upsell_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
	<div class="container">
		<div class="col-md-12 tabs">
			<div class="tabs">
				<div class="tab_bg">
					<form class="upsellForm">
						<ul class="nav nav-tabs" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" data-toggle="tab" href="#home">
                                    <i class="fas fa-cogs"></i>Configuration
								</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" data-toggle="tab" href="#menu1">
									<i class="fa fa-image"></i>Preview
								</a>
							</li>
							<li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#menu-fbt-video">
                                <i class="fas fa-video"></i>Video Guide
                                </a>
                            </li>
						</ul>
						<!----------------Tab-panes----------------->
						<div class="tab-content mt-3">
							<div id="home" class="tab-pane active">
								<div class="container offer">
									<div class="row">
										<div class="col-md-5 offer_left">
											<h4>Offer Name</h4>
											<p>This is an internal name and won't appear on the frontend.</p>
										</div>
										<div class="col-md-7 offer_right">
											<label>Name:</label><br>
											<input type="text" placeholder="Enter Offer Name...!!" id="offer_name" name="name" <?php if(isset($upsell)): ?> value = "<?php echo e($upsell->name); ?>"<?php endif; ?>>
										</div>
									</div>
								</div>
								<div class="container">
									<div class="row">
										<div class="col-md-5 offer_left">
											<h4>Select Target Products</h4>
											<p>
											Target products are those products, on which you want to show an offer. When an order of customer is completed, then an offer will be shown on those products.
											</p>
										</div>
										<div class="col-md-7 offer_right select_bg">
											<div class="row mt-2">
												<div class="col-md-4 select_left">
													<h3>Upsell will Trigger on...</h3>
												</div>
												<div class="col-md-8 select_right">
													<button type="button" class="save pickTProduct" data-toggle="modal"
														data-target="#product_modal">Pick a Product</button>
													<button type="button" class="cancel removeAll">Remove All</button>
												</div>
											</div>
											<hr>
											<div class="pickedTriggerOn itemContainer">
												<?php if(isset($upsell)): ?>
                                                    <?php if($upsell->Tproducts->count()): ?>
                                                        <?php $__currentLoopData = $upsell->Tproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="box_shado mt">
                                                                <input class="tabValues" type="hidden" name="Tproducts[]" value="<?php echo e($tProduct->shopify_product_id); ?>">
                                                                <input class="tabValues" type="hidden" name="Tproductsimages[]" value="<?php echo e($tProduct->shopify_product_image); ?>">
                                                                <input class="tabValues" type="hidden" name="Tproductstitles[]" value="<?php echo e($tProduct->shopify_product_title); ?>">
                                                                <div class="row">
                                                                    <div class="img_box col-md-2">
                                                                        <img src="<?php echo e($tProduct->shopify_product_image); ?>">
                                                                    </div>
                                                                    <div class="img_name col-md-8">
                                                                        <p><?php echo e($tProduct->shopify_product_title); ?>

                                                                        </p>
                                                                    </div>
                                                                    <div class="img_btn col-md-2">
                                                                        <button type="button" class="delete float-right deleteItem">Delete</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif($upsell->Tcollections->count()): ?>
                                                        <?php $__currentLoopData = $upsell->Tcollections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tCollection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <input class="tabValues" type="hidden" name="Tcollections[]" value="<?php echo e($tCollection->shopify_collection_id); ?>">
                                                            <input class="tabValues" type="hidden" name="Tcollectionsimages[]" value="<?php echo e($tCollection->shopify_collection_image); ?>">
                                                            <input class="tabValues" type="hidden" name="Tcollectionstitles[][]" value="<?php echo e($tCollection->shopify_collection_title); ?>">

                                                            <div class="box_shado mt">
                                                                <div class="row">
                                                                    <div class="img_box col-md-2">
                                                                        <img src="<?php echo e($tCollection->shopify_collection_image); ?>">
                                                                    </div>
                                                                    <div class="img_name col-md-8">
                                                                        <p><?php echo e($tCollection->shopify_collection_title); ?>

                                                                        </p>
                                                                    </div>
                                                                    <div class="img_btn col-md-2">
                                                                        <button type="button" class="delete float-right deleteItem">Delete</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif($upsell->Ttags->count()): ?>
                                                        <?php $__currentLoopData = $upsell->Ttags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tTags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="box_shado mt">
                                                                <input class="tabValues" type="hidden" name="Ttags[]" value="<?php echo e($tTags->shopify_tag_id); ?>">
                                                                <input class="tabValues" type="hidden" name="Ttagsimages[]" value="<?php echo e($tTags->shopify_tag_image); ?>">
                                                                <input class="tabValues" type="hidden" name="Ttagstitles[]" value="<?php echo e($tTags->shopify_tag_title); ?>">
                                                                <div class="row">
                                                                    <div class="img_box col-md-2">
                                                                        <img src="<?php echo e($tTags->shopify_tag_image); ?>">
                                                                    </div>
                                                                    <div class="img_name col-md-8">
                                                                        <p><?php echo e($tTags->shopify_tag_title); ?>

                                                                        </p>
                                                                    </div>
                                                                    <div class="img_btn col-md-2">
                                                                        <button type="button" class="delete float-right deleteItem">Delete</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
											</div>
										</div>
									</div>
								</div>
								<div class="container upsel_p">
									<div class="row">
										<div class="col-md-5 offer_left">
											<h4>Select Upsell Products</h4>
											<p>
											Upsell products are those products, which you want to show in the offer. When customers will add targeted product to order, then upsell products will be shown on thank you page.
											</p>
										</div>
										<div class="col-md-7 offer_right select_bg">
											<div class="row mt-2">
												<div class="col-md-4 select_left">
													<h3>Upsell will Appear on...</h3>
												</div>
												<div class="col-md-8 select_right">
													<input class="autoHidden" type="hidden" name="auto" value="0">
													<button type="button" class="save pickAProduct" data-toggle="modal"
														data-target="#product_modal">Pick a Product</button>
													<button type="button" class="cancel removeAll">Remove All</button>
												</div>
											</div>
											<hr>
											<div class="pickedAppearOn itemContainer">
												 <?php if(isset($upsell)): ?>
                                                    <?php if($upsell->Aproducts->count()): ?>
                                                        <?php $__currentLoopData = $upsell->Aproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="box_shado mt">
                                                                <input class="tabValues" type="hidden" name="Aproducts[]" value="<?php echo e($aProduct->shopify_product_id); ?>">
                                                                <input class="tabValues" type="hidden" name="Aproductsimages[]" value="<?php echo e($aProduct->shopify_product_image); ?>">
                                                                <input class="tabValues" type="hidden" name="Aproductstitles[]" value="<?php echo e($aProduct->shopify_product_title); ?>">
                                                                <div class="row">
                                                                    <div class="img_box col-md-2">
                                                                        <img src="<?php echo e($aProduct->shopify_product_image); ?>">
                                                                    </div>
                                                                    <div class="img_name col-md-8">
                                                                        <p><?php echo e($aProduct->shopify_product_title); ?>

                                                                        </p>
                                                                    </div>
                                                                    <div class="img_btn col-md-2">
                                                                        <button type="button" class="delete float-right deleteItem">Delete</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif($upsell->Acollections->count()): ?>
                                                        <?php $__currentLoopData = $upsell->Acollections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aCollection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="box_shado mt">
                                                                <input class="tabValues" type="hidden" name="Acollections[]" value="<?php echo e($aCollection->shopify_collection_id); ?>">
                                                                <input class="tabValues" type="hidden" name="Acollectionsimages[]" value="<?php echo e($aCollection->shopify_collection_image); ?>">
                                                                <input class="tabValues" type="hidden" name="Acollectionstitles[]" value="<?php echo e($aCollection->shopify_collection_title); ?>">
                                                                <div class="row">
                                                                    <div class="img_box col-md-2">
                                                                        <img src="<?php echo e($aCollection->shopify_collection_image); ?>">
                                                                    </div>
                                                                    <div class="img_name col-md-8">
                                                                        <p><?php echo e($aCollection->shopify_collection_title); ?>

                                                                        </p>
                                                                    </div>
                                                                    <div class="img_btn col-md-2">
                                                                        <button type="button" class="delete float-right deleteItem">Delete</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php elseif($upsell->Atags->count()): ?>
                                                        <?php $__currentLoopData = $upsell->Atags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aTags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="box_shado mt">
                                                                <input class="tabValues" type="hidden" name="Atags[]" value="<?php echo e($aTags->shopify_tag_id); ?>">
                                                                <input class="tabValues" type="hidden" name="Atagsimages[]" value="<?php echo e($aTags->shopify_tag_image); ?>">
                                                                <input class="tabValues" type="hidden" name="Atagstitles[]" value="<?php echo e($aTags->shopify_tag_title); ?>">
                                                                <div class="row">
                                                                    <div class="img_box col-md-2">
                                                                        <img src="<?php echo e($aTags->shopify_tag_image); ?>">
                                                                    </div>
                                                                    <div class="img_name col-md-8">
                                                                        <p><?php echo e($aTags->shopify_tag_title); ?>

                                                                        </p>
                                                                    </div>
                                                                    <div class="img_btn col-md-2">
                                                                        <button type="button" class="delete float-right deleteItem">Delete</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                <?php endif; ?>
											</div>
										</div>
									</div>
								</div>
								<div class="container offer">
									<div class="row">
										<div class="col-md-5 offer_left">
											<h4>Discount Details</h4>
											<p>Choose the discount type here whether you want to apply discount in percentage, a fix price or no discount.</p>
										</div>
										<div class="col-md-7 offer_right">
											<div class="row">
												<div class="col-md-6 discount_left">
													<label>Discount Type:</label><br>
													<select name="discount_price_option">
														<option
															<?php if(isset($upsell)): ?>
                                                                <?php echo e($upsell->setting['discount_price_option'] == "% Off" ? "selected" : ''); ?>

                                                            <?php else: ?>
                                                                <?php echo e($upsellType->setting['upsell_discount_type'] == "% Off" ? "selected" : ''); ?>

                                                            <?php endif; ?>
															value="% Off">% Off
														</option>
														<option
															<?php if(isset($upsell)): ?>
                                                                <?php echo e($upsell->setting['discount_price_option'] == "Fixed Price Off" ? "selected" : ''); ?>

                                                            <?php else: ?>
                                                                <?php echo e($upsellType->setting['upsell_discount_type'] == "Fixed Price Off" ? "selected" : ''); ?>

                                                            <?php endif; ?>
															value="Fixed Price Off">Fixed Price Off
														</option>
														<option
															<?php if(isset($upsell)): ?>
                                                                <?php echo e($upsell->setting['discount_price_option'] == "No Discount" ? "selected" : ''); ?>

                                                            <?php else: ?>
                                                                <?php echo e($upsellType->setting['upsell_discount_type'] == "No Discount" ? "selected" : ''); ?>

                                                            <?php endif; ?>
															values="No Discount">No Discount
														</option>
													</select>
												</div>
												<div class="col-md-6 discount_left">
													<label>Discount Value:</label><br>
													<input type="number" value=
														<?php if(isset($upsell)): ?>
															"<?php echo e($upsell->setting['upsell_discount']); ?>"
														<?php else: ?>
															"<?php echo e($upsellType->setting['upsell_discount']); ?>"
														<?php endif; ?>
														min="0" name="upsell_discount">
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="container offer">
									<div class="row">
										<div class="col-md-5 offer_left">
											<h4>Optional Settings</h4>
											<p></p>
										</div>
										<div class="col-md-7 select_bg display">
											<h4>Work on device:</h4>
											<p>
												<div class="row">
													<div class="form-check form_float ml-3">
														<input
															<?php if(isset($upsell)): ?>
																<?php echo e($upsell->setting['work_on_desktop']  ? "checked" : ''); ?>

															<?php else: ?>
																<?php echo e($upsellType->setting['work_on_desktop']  ? "checked" : ''); ?>

															<?php endif; ?>
															name="work_on_desktop" type="checkbox" class="form-check-input" id="formCheck-1"
															style="height: 20px;" class="work_on_desktop" value="1" checked>
														<label class="form-check-label" for="formCheck-1">Desktop</label>
													</div>
													<div class="form-check form_float">
														<input
															<?php if(isset($upsell)): ?>
																<?php echo e($upsell->setting['work_on_mobile']  ? "checked" : ''); ?>

															<?php else: ?>
																<?php echo e($upsellType->setting['work_on_mobile']  ? "checked" : ''); ?>

															<?php endif; ?>
															name="work_on_mobile" type="checkbox" class="form-check-input" id="formCheck-3"
															style="height: 20px;" class="work_on_mobile" value="1" checked>
														<label class="form-check-label" for="formCheck-3">Mobile</label>
													</div>
												</div>
											</p>
											<hr>
											<h4>Schedule:</h4>
											<div class="row">
												<div class="col-md-6 discount_left">
													<label>Start Date:</label><br>
													<input value=
														<?php if(isset($upsell)): ?>
															"<?php echo e($upsell->setting['start_date']); ?>"
														<?php else: ?>
															"<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>"
														<?php endif; ?>
														name="start_date" type="date">
												</div>
												<div class="col-md-6 discount_left">
													<label>End Date:</label><br>
													<input class="end_date"	name="end_date" type="date" style="background-color: #dadada;">
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-------------------tab-1-close--------------------->
							<div id="menu1" class="tab-pane fade p-0"><br>
								<div class="container-fluid">
									<div class="container">
										<div class="row">
											<div class="col-md-6">
												<div class="design_input">
													<h3>Title</h3>
													<p class="h_input">
														<label>Heading</label><br>
														<input type="text" value=
														<?php if(isset($upsell)): ?>
															"<?php echo e($upsell->setting['ppu_heading']); ?>"
														<?php else: ?>
															"<?php echo e($upsellType->setting['ppu_heading']); ?>"
														<?php endif; ?>
														name="ppu_heading" type="text" placeholder="15% OFF! Timer until the offer expires:">
													</p>
													<div class="col-md-12 font">
														<div class="row">
															<p class="f_input">
																<label>Font family</label><br>
																<select name="heading_font_family">
																	<?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																		<option
																		<?php if(isset($upsell)): ?>
																			<?php echo e($upsell->setting['heading_font_family'] == $family ? "selected" : ''); ?>

																		<?php else: ?>
																			<?php echo e($upsellType->setting['heading_font_family'] == $family ? "selected" : ''); ?>

																		<?php endif; ?>
																		 value="<?php echo e($family); ?>">
																			<?php echo e($family); ?>

																		</option>
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																</select>
															</p>
															<p class="f_input">
																<label>Font Size</label><br>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['heading_font_size']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['heading_font_size']); ?>"
																	<?php endif; ?>
																	name="heading_font_size" type="number" value="22" min="12">
															</p>
														</div>
													</div>
													<div class="col-md-12 font">
														<div class="row">
															<div class="f_input_color">
																<label>Color</label><br>
																<a href="#" data-id="heading_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['heading_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['heading_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['heading_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['heading_color']); ?>"
																	<?php endif; ?>
																	type="hidden" name="heading_color">
																<p>Text Color </p>
															</div>
															<p class="f_input">
																<label>Text Align</label><br>
																<select name="heading_align">
																	<option
																		<?php if(isset($upsell)): ?>
																			<?php echo e($upsell->setting['heading_align'] == "left" ? "selected" : ''); ?>

																		<?php else: ?>
																			<?php echo e($upsellType->setting['heading_align'] == "left" ? "selected" : ''); ?>

																		<?php endif; ?>
																		value="left">Left
																	</option>
																	<option
																		<?php if(isset($upsell)): ?>
																			<?php echo e($upsell->setting['heading_align'] == "center" ? "selected" : ''); ?>

																		<?php else: ?>
																			<?php echo e($upsellType->setting['heading_align'] == "center" ? "selected" : ''); ?>

																		<?php endif; ?>
																		value="center">Center
																	</option>
																	<option
																		<?php if(isset($upsell)): ?>
																			<?php echo e($upsell->setting['heading_align'] == "right" ? "selected" : ''); ?>

																		<?php else: ?>
																			<?php echo e($upsellType->setting['heading_align'] == "right" ? "selected" : ''); ?>

																		<?php endif; ?>
																		value="right">Right
																		</option>
																</select>
															</p>
														</div>
													</div>
													<h3>Countdown Sales Timer</h3>
													<div class="custom-control custom-checkbox">
														<input name="time_limit_toggler" type="checkbox" class="custom-control-input" id="defaultCheckedDisabled2"
														<?php if(isset($upsell)): ?>
															<?php echo e($upsell->setting['time_limit_toggler']== 1 ? "checked" : ''); ?>

														<?php else: ?>
															<?php echo e($upsellType->setting['time_limit']== 1 ? "checked" : ''); ?>

														<?php endif; ?>
														value=
														<?php if(isset($upsell)): ?>
															"<?php echo e($upsell->setting['time_limit_toggler']); ?>"
														<?php else: ?>
															"<?php echo e($upsellType->setting['time_limit']); ?>"
														<?php endif; ?>
														>
														<label class="custom-control-label" for="defaultCheckedDisabled2">Add a Time Limit To The Offer</label>
													</div>

														<p class="h_input">
														<label> Timer Text</label><br>
														<input type="text" name="thank_you_timer_text" value=
                                                        <?php if(isset($upsell)): ?>
                                                            "<?php echo e($upsell->setting['thank_you_timer_text']); ?>"
                                                        <?php else: ?>
                                                            "<?php echo e($upsellType->setting['thank_you_timer_text']); ?>"
                                                        <?php endif; ?>
                                                        />
														</p>
														<div class="col-md-12 font">
														<div class="row">
														<div class="f_input_color">
																<a href="#" data-id="thank_you_timer_text_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['thank_you_timer_text_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['thank_you_timer_text_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input name="thank_you_timer_text_color" type="hidden" value=
                                                                    <?php if(isset($upsell)): ?>
                                                                        "<?php echo e($upsell->setting['thank_you_timer_text_color']); ?> "
                                                                    <?php else: ?>
                                                                        "<?php echo e($upsellType->setting['thank_you_timer_text_color']); ?> "
                                                                    <?php endif; ?>
                                                                />
																<p>Timer Text Color </p>
														</div>
														<div class="f_input_color">
																<a href="#" data-id="thank_you_timer_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['thank_you_timer_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['thank_you_timer_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input name="thank_you_timer_color" type="hidden" value=
                                                                <?php if(isset($upsell)): ?>
                                                                    "<?php echo e($upsell->setting['thank_you_timer_color']); ?>"
                                                                <?php else: ?>
                                                                    "<?php echo e($upsellType->setting['thank_you_timer_color']); ?>"
                                                                <?php endif; ?>
                                                                />
																<p>Timer Color </p>
														</div>
														<div class="f_input_color">
																<a href="#" data-id="thank_you_timer_text_bg_color" class="buttoncolor colorpicker" style=
                                                                    <?php if(isset($upsell)): ?>
                                                                        "background-color:<?php echo e($upsell->setting['thank_you_timer_text_bg_color']); ?>;"
                                                                    <?php else: ?>
                                                                        "background-color:<?php echo e($upsellType->setting['thank_you_timer_text_bg_color']); ?>;"
                                                                    <?php endif; ?>
                                                                >
																</a>
																<input name="thank_you_timer_text_bg_color" type="hidden" value=
                                                                <?php if(isset($upsell)): ?>
                                                                    "<?php echo e($upsell->setting['thank_you_timer_text_bg_color']); ?>"
                                                                <?php else: ?>
                                                                    "<?php echo e($upsellType->setting['thank_you_timer_text_bg_color']); ?>"
                                                                <?php endif; ?>
                                                                />
																<p>Timer background Color </p>
														</div>

													</div>
													</div>
													<p class="h_input">
														<label>Timer Duration In Minutes</label><br>
														<input type="number" name="timer_duration" value=
															<?php if(isset($upsell)): ?>
																"<?php echo e($upsell->setting['timer_duration']); ?>"
															<?php else: ?>
																"<?php echo e($upsellType->setting['timer_duration']); ?>"
															<?php endif; ?>
															name="timer_duration">
													</p>
													<div class="col-md-12 font">
														<div class="row">
															<p class="f_input">
																<label>Font family</label><br>
																<select name="timer_font_family">
																	<?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																		<option
																			<?php if(isset($upsell)): ?>
																				<?php echo e($upsell->setting['timer_font_family'] == $family ? "selected" : ''); ?>

																			<?php else: ?>
																				<?php echo e($upsellType->setting['timer_font_family'] == $family ? "selected" : ''); ?>

																			<?php endif; ?>
																			value="<?php echo e($family); ?>">
																			<?php echo e($family); ?>

																		</option>
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																</select>
															</p>
															<p class="f_input">
																<label>Font Size</label><br>
																<input type="number" value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['timer_font_size']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['timer_font_size']); ?>"
																	<?php endif; ?>
																	min="12" name="timer_font_size">
															</p>
														</div>
													</div>
													<h3 class="mt-4">Translation</h3>
													<p class="h_input">
														<label>Button Text</label><br>
														<input type="text" value=
															<?php if(isset($upsell)): ?>
																"<?php echo e($upsell->setting['ppu_button_text']); ?>"
															<?php else: ?>
																"<?php echo e($upsellType->setting['button_text']); ?>"
															<?php endif; ?>
															name="ppu_button_text">
													</p>
													<div class="col-md-12">
														<div class="row">
															<div class="custom-control custom-checkbox">
																<input type="checkbox" class="custom-control-input" name="show_ppu_product_title" id="defaultCheckedDisabled5"
																	<?php if(isset($upsell)): ?>
																		<?php echo e($upsell->setting['show_ppu_product_title']==1 ? 'checked':''); ?>

																	<?php else: ?>
																		<?php echo e($upsellType->setting['show_product_title']==1 ? 'checked':''); ?>

																	<?php endif; ?>
																	value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['show_ppu_product_title']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['show_product_title']); ?>"
																	<?php endif; ?>
																	>
																<label class="custom-control-label" for="defaultCheckedDisabled5">Show Product Title</label>
															</div>
															<div class="custom-control custom-checkbox">
																<input type="checkbox" value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['show_ppu_varient_selection']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['show_varient_selection']); ?>"
																	<?php endif; ?>
																	class="custom-control-input" id="defaultCheckedDisabled3" name ="show_ppu_varient_selection"
																	<?php if(isset($upsell)): ?>
																		<?php echo e($upsell->setting['show_ppu_varient_selection']==1 ? 'checked':''); ?>

																	<?php else: ?>
																		<?php echo e($upsellType->setting['show_varient_selection']==1 ? 'checked':''); ?>

																	<?php endif; ?>
																	>
																<label class="custom-control-label" for="defaultCheckedDisabled3">Show Variant Selection</label>
															</div>
														</div>
													</div>
													<h3 class="mt-4">Color Settings</h3>
													<div class="col-md-12 font">
														<div class="row">
															<div class="f_input_color mt-3">
																<a href="#" data-id="product_title_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['product_title_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['product_title_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['product_title_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['product_title_color']); ?>"
																	<?php endif; ?>
																	type="hidden" name="product_title_color">
																<p>Product Title </p>
															</div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="my_upsell_background_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['my_upsell_background_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['upsell_background_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['my_upsell_background_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['upsell_background_color']); ?>"
																	<?php endif; ?>
																 type="hidden" name="my_upsell_background_color">
																<p>Upsell Background </p>
															</div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="sale_price_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['sale_price_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['sale_price_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['sale_price_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['sale_price_color']); ?>"
																	<?php endif; ?>
																	type="hidden" name="sale_price_color">
																<p>Sale Price </p>
															</div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="discount_text_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['discount_text_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['discount_text_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['discount_text_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['discount_text_color']); ?>"
																	<?php endif; ?>
																	type="hidden" name="discount_text_color">
																<p>Discount Text </p>
															</div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="discount_background_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['discount_background_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['discount_background_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['discount_background_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['discount_background_color']); ?>"
																	<?php endif; ?>
																	type="hidden" name="discount_background_color">
																<p>Discount Background </p>
															</div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="button_border_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['button_border_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['button_border_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['button_border_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['button_border_color']); ?>"
																	<?php endif; ?>
																	type="hidden" name="button_border_color">
																<p>Button Border Color</p>
															</div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="button_text_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['button_text_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['button_text_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['button_text_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['button_text_color']); ?>"
																	<?php endif; ?>
																	type="hidden" name="button_text_color">
																<p>Button Text</p>
															</div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="button_hover_text_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['button_hover_text_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['button_hover_text_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['button_hover_text_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['button_hover_text_color']); ?>"
																	<?php endif; ?>
																	type="hidden" name="button_hover_text_color">
																<p>Button Hover Text </p>
															</div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="button_background_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['button_background_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['button_background_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input value=
																	<?php if(isset($upsell)): ?>
																		"<?php echo e($upsell->setting['button_background_color']); ?>"
																	<?php else: ?>
																		"<?php echo e($upsellType->setting['button_background_color']); ?>"
																	<?php endif; ?>
																	type="hidden" name="button_background_color">
																<p>Button background</p>
															</div>
                                                            <div class="f_input_color mt-3">
                                                                <a href="#" data-id="button_hover_background_color" class="buttoncolor colorpicker" style=
                                                                    <?php if(isset($upsell)): ?>
                                                                        "background-color:<?php echo e($upsell->setting['button_hover_background_color']); ?>;"
                                                                    <?php else: ?>
                                                                        "background-color:<?php echo e($upsellType->setting['button_hover_background_color']); ?>;"
                                                                    <?php endif; ?>
                                                                >
                                                                </a>
                                                                <input value=
                                                                    <?php if(isset($upsell)): ?>
                                                                        "<?php echo e($upsell->setting['button_hover_background_color']); ?>"
                                                                    <?php else: ?>
                                                                        "<?php echo e($upsellType->setting['button_hover_background_color']); ?>"
                                                                    <?php endif; ?>
                                                                    type="hidden" name="button_hover_background_color">
                                                                <p>Button Hover Background</p>
                                                            </div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="arrow_icon_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['arrow_icon_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['arrow_icon_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input name="arrow_icon_color" type="hidden" value=
                                                                <?php if(isset($upsell)): ?>
                                                                    "<?php echo e($upsell->setting['arrow_icon_color']); ?>"
                                                                <?php else: ?>
                                                                    "<?php echo e($upsellType->setting['arrow_icon_color']); ?>"
                                                                <?php endif; ?>
                                                                />
																<p>Icon Color</p>
															</div>
															<div class="f_input_color mt-3">
																<a href="#" data-id="arrow_icon_background_color" class="buttoncolor colorpicker" style=
																	<?php if(isset($upsell)): ?>
																		"background-color:<?php echo e($upsell->setting['arrow_icon_background_color']); ?>;"
																	<?php else: ?>
																		"background-color:<?php echo e($upsellType->setting['arrow_icon_background_color']); ?>;"
																	<?php endif; ?>
																>
																</a>
																<input name="arrow_icon_background_color" type="hidden" value=
                                                                <?php if(isset($upsell)): ?>
                                                                    "<?php echo e($upsell->setting['arrow_icon_background_color']); ?>"
                                                                <?php else: ?>
                                                                    "<?php echo e($upsellType->setting['arrow_icon_background_color']); ?>"
                                                                <?php endif; ?>
                                                                />
																<p>Icon Background Color</p>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="design_p_inpage">
													<div class="design_inpage_post custom_upsell_background_color">
														<div class="top_head_post">
															<div class="post_timer offer_timer" style="width: 200px;">
																<p  class="offer_timer time_display offer_text"style="font-size:15px !important;">Offer End Soon:&nbsp;</p>
																<p  class="offer_timer time_display display_timer_counter "style="font-size:15px !important;">
																	<?php if(isset($upsell)): ?>
																		<?php echo e($upsell->setting['timer_duration']); ?>

																	<?php else: ?>
																		<?php echo e($upsellType->setting['timer_duration']); ?>

																	<?php endif; ?>
																</p>
																<p  class="offer_timer time_display display_timer_counter "style="font-size:15px !important;">:00</p>
															</div>
															<h3 class="ppu_heading_style">
																<?php if(isset($upsell)): ?>
																	<?php echo e($upsell->setting['ppu_heading']); ?>

																<?php else: ?>
																	<?php echo e($upsellType->setting['ppu_heading']); ?>

																<?php endif; ?>
															</h3><br>
														</div>
														<div class="body_post">
															<div class="slideshow-container">
																<div class="mySlides">
																	<div class="post">
																		<div class="post_p">
																			<div class="post_img">
																				<img src="<?php echo e(asset('assets/img/m-1-2.webp')); ?>" alt="shoes">
																			</div>
																			<div class="post_detail">
																				<h4 class="toggle_product_title">Women Pumps Comfort High Heels</h4>
																				<p class="product_sale_price"><?php echo e($currency); ?>39.95
																				<span class="discount_offer discount_offer_style">
																					<?php if(isset($upsell)): ?>
																						<?php echo e($upsell->setting['upsell_discount']); ?>% Off
																					<?php else: ?>
																						<?php echo e($upsellType->setting['upsell_discount']); ?>% Off
																					<?php endif; ?>
																				</span>
																				<span class="fixed_price_off discount_offer_style">
																					<?php if(isset($upsell)): ?>
																						$<?php echo e($upsell->setting['upsell_discount']); ?>Off
																					<?php else: ?>
																						$<?php echo e($upsellType->setting['upsell_discount']); ?>Off
																					<?php endif; ?>
																				</span>
																				</p>
																				<select class="toggle_varient_selection">
																					<option>Yellow</option>
																					<option>Blue</option>
																					<option>Red</option>
																				</select>
																				<input type="button" value=
																					<?php if(isset($upsell)): ?>
																						"<?php echo e($upsell->setting['ppu_button_text']); ?>"
																					<?php else: ?>
																						"<?php echo e($upsellType->setting['button_text']); ?>"
																					<?php endif; ?>
																				   class="ppu_button ppu_button_1" style=
																					<?php if(isset($upsell)): ?>
																						"color:<?php echo e($upsell->setting['button_text_color']); ?>;"
																					<?php else: ?>
																						"color:<?php echo e($upsellType->setting['button_text_color']); ?>;"
																					<?php endif; ?>
																				>
																			</div>
																		</div>
																	</div>
																	<div class="post">
																		<div class="post_p">
																			<div class="post_img">
																				<img src="<?php echo e(asset('assets/img/m-6-2.jpg')); ?>" alt="shoes">
																			</div>
																			<div class="post_detail">
																				<h4 class="toggle_product_title">Women's handbag Female leather shoulder bag..!!</h4>
																				<p class="product_sale_price"><?php echo e($currency); ?>29.95
																				<span class="discount_offer discount_offer_style">
																					<?php if(isset($upsell)): ?>
																						<?php echo e($upsell->setting['upsell_discount']); ?>% Off
																					<?php else: ?>
																						<?php echo e($upsellType->setting['upsell_discount']); ?>% Off
																					<?php endif; ?>
																				</span>
																				<span class="fixed_price_off discount_offer_style">
																					<?php if(isset($upsell)): ?>
																						$<?php echo e($upsell->setting['upsell_discount']); ?> Off
																					<?php else: ?>
																						$<?php echo e($upsellType->setting['upsell_discount']); ?> Off
																					<?php endif; ?>
																				</span>
																				</p>
																				<select class="toggle_varient_selection">
																					<option>Black</option>
																					<option>Blue</option>
																					<option>Red</option>
																				</select>
																				<input type="button" value=
																					<?php if(isset($upsell)): ?>
																						"<?php echo e($upsell->setting['ppu_button_text']); ?>"
																					<?php else: ?>
																						"<?php echo e($upsellType->setting['button_text']); ?>"
																					<?php endif; ?>
																					class="ppu_button ppu_button_2" style=
																					<?php if(isset($upsell)): ?>
																						"color:<?php echo e($upsell->setting['button_text_color']); ?>;"
																					<?php else: ?>
																						"color:<?php echo e($upsellType->setting['button_text_color']); ?>;"
																					<?php endif; ?>
																				>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="mySlides">
																	<div class="post">
																		<div class="post_p">
																			<div class="post_img">
																				<img src="<?php echo e(asset('assets/img/m-1-3.webp')); ?>" alt="shoes">
																			</div>
																			<div class="post_detail">
																				<h4 class="toggle_product_title">Women Pumps Comfort High Heels</h4>
																				<p class="product_sale_price">$39.95
																				<span class="discount_offer discount_offer_style"><?php echo e($upsellType->setting['upsell_discount']); ?>% Off</span>
																				<span class="fixed_price_off discount_offer_style">$<?php echo e($upsellType->setting['upsell_discount']); ?> Off</span>
																				</p>
																				<select class="toggle_varient_selection">
																					<option>Black</option>
																					<option>Blue</option>
																					<option>Red</option>
																				</select>
																				<select class="toggle_varient_selection">
																					<option>24</option>
																					<option>26</option>
																					<option>28</option>
																				</select>
																				<input type="button" value=
																					<?php if(isset($upsell)): ?>
																						"<?php echo e($upsell->setting['ppu_button_text']); ?>"
																					<?php else: ?>
																						"<?php echo e($upsellType->setting['button_text']); ?>"
																					<?php endif; ?>
																				    class="ppu_button ppu_button_3" style=
																					<?php if(isset($upsell)): ?>
																						"color:<?php echo e($upsell->setting['button_text_color']); ?>;"
																					<?php else: ?>
																						"color:<?php echo e($upsellType->setting['button_text_color']); ?>;"
																					<?php endif; ?>
																					>
																			</div>
																		</div>
																	</div>
																	<div class="post">
																		<div class="post_p">
																			<div class="post_img">
																				<img src="<?php echo e(asset('assets/img/m-1-5.jpg')); ?>" alt="shoes">
																			</div>
																			<div class="post_detail">
																				<h4 class="toggle_product_title">Women Pumps Comfort High Heels</h4>
																				<p class="product_sale_price">$39.95
																				<span class="discount_offer discount_offer_style">
																					<?php if(isset($upsell)): ?>
																						<?php echo e($upsell->setting['upsell_discount']); ?>% Off
																					<?php else: ?>
																						<?php echo e($upsellType->setting['upsell_discount']); ?>% Off
																					<?php endif; ?>
																				</span>
																				<span class="fixed_price_off discount_offer_style">
																					<?php if(isset($upsell)): ?>
																						$<?php echo e($upsell->setting['upsell_discount']); ?> Off
																					<?php else: ?>
																						$<?php echo e($upsellType->setting['upsell_discount']); ?> Off
																					<?php endif; ?>
																				</span>
																				</p>
																				<select class="toggle_varient_selection">
																					<option>White</option>
																					<option>Blue</option>
																					<option>Red</option>
																				</select>
																				<input type="button" value=
																				 	<?php if(isset($upsell)): ?>
																						"<?php echo e($upsell->setting['ppu_button_text']); ?>"
																					<?php else: ?>
																						"<?php echo e($upsellType->setting['button_text']); ?>"
																					<?php endif; ?>
																				  class="ppu_button ppu_button_4" style=
																					<?php if(isset($upsell)): ?>
																						"color:<?php echo e($upsell->setting['button_text_color']); ?>;"
																					<?php else: ?>
																						"color:<?php echo e($upsellType->setting['button_text_color']); ?>;"
																					<?php endif; ?>
																				>
																			</div>
																		</div>
																	</div>
																</div>
																<a class="prev arrow-icon" onclick="plusSlides(-1)">❮</a>
																<a class="next arrow-icon" onclick="plusSlides(1)">❯</a>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!-----------------Tab-2-Close----------------->
							<div id="menu-fbt-video" class="tab-pane fade p-0"><br><div class="container-fluid">
                        	<div class="container">
                             <div class="row">
                              <div class="col-md-12">
                                 <iframe width="100%" height="515" src="https://www.youtube.com/embed/RTT0t7WM22g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                              </div>
                           </div>
                        	</div>
                        	</div>
                     		</div>



						</div>
					</form>
				</div>
			</div>

		</div>
	</div>
</div>

<?php echo $__env->make('includes.components.pickProductModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.pages.ppu',[ "setting" => $upsellType->setting ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('vendor.shopify-app.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/thank_you.blade.php ENDPATH**/ ?>