<!DOCTYPE html>
<html>
<head>
	<title>Uninstall</title>
</head>
	<body>
	<p>
		Hello <b>{{$data['name']}}</b>
	</p>
	<p>
		I'm sorry to see you go.
	</p>
	<p> 
		If you've experienced any issues with our <b>ALPHA GOOGLE SHOPPING FEED</b>, please let me know and I will contact you right away with a fix to the issue. If there is also any feature that you would have loved to see in our app just let me know and we will do our best to integrate it.
	</p>
	<p>
		Simply go to your section 'Apps' and click Delete on the right side of the app listing:
	</p>
	<p>Hope to hear from you!
	</p>
	<p>Best wishes,</p>
	<p>ALPHA GOOGLE SHOPPING FEED
	</p>
	</body>
</html>