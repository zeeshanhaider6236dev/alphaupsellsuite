<div class="modal fade" id="centralModalSm6" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
   aria-hidden="true">
   <!-- Change class .modal-sm to change the size of the modal -->
   <form class="template-<?php echo e($upsellTemplateId); ?>">
      <div class="modal-dialog modal-sm m_1_w" role="document">
         <div class="modal-content modal_1_show" style="height: 100vh;">
            <div class="modal-header">
               <h4 class="modal-title w-100 m_head_h">Customize Your Template</h4>
               <button type="button" class="close m1_close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body m_1_body">
               <div class="container">
                  <div class="col-md-12 popup_page">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="design_input">
                              <h3>Title</h3>
                              <p class="h_input">
                                 <label>Heading</label><br>
                                 <input type="text" name="alpha_t6_top_heading" value=
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          "<?php echo e($upsell->setting['alpha_t6_top_heading']); ?>"   
                                       <?php else: ?>    
                                          "<?php echo e($setting['top_heading']); ?>"
                                       <?php endif; ?>
                                    <?php else: ?>
                                       "<?php echo e($setting['top_heading']); ?>"
                                    <?php endif; ?> 
                                 >
                              </p>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Font Family</label><br>
                                       <select name="alpha_t6_top_heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>" 
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['alpha_t6_top_heading_font_family']  == $family ? "selected":""); ?>   
                                                   <?php else: ?>    
                                                       <?php echo e($setting['top_heading_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($setting['top_heading_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?> 
                                             >
                                                <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Font Size</label><br>
                                       <input type="number" name="alpha_t6_top_heading_font_size" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_top_heading_font_size']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['top_heading_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['top_heading_font_size']); ?>"
                                          <?php endif; ?> 
                                       >
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_top_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_top_heading_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_top_heading_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_top_heading_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_heading_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Heading Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_cross_icon_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_cross_icon_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cross_icon_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_cross_icon_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_cross_icon_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cross_icon_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Icon Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_cross_icon_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_cross_icon_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cross_icon_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_cross_icon_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_cross_icon_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cross_icon_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Icon Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Cart Product</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_cart_product_title_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_cart_product_title_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_product_title_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_product_title_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_cart_product_title_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_cart_product_title_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_product_title_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_product_title_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Title Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_cart_product_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_cart_product_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_product_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_product_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_cart_product_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_cart_product_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_product_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_product_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Background Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_cart_product_price_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_cart_product_price_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cart_product_price_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cart_product_price_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_cart_product_price_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_cart_product_price_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cart_product_price_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cart_product_price_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Price Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Product</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Title</label><br>
                                       <input type="text" placeholder="You May Be Interested In..." name="alpha_t6_product_heading" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_product_heading']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['offer_heading']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['offer_heading']); ?>"
                                          <?php endif; ?> 
                                       >
                                    </p>
                                    <p class="f_input">
                                       <label>Button Text</label><br>
                                       <input type="text" placeholder="Add To Cart" name="alpha_t6_cart_btn" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_cart_btn']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['add_to_cart_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['add_to_cart_text']); ?>"
                                          <?php endif; ?> 
                                       >
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_product_title_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_product_title_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['offer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['offer_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_product_title_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_product_title_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['offer_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['offer_heading_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Title Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_price_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_price_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['orignal_price_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['orignal_price_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_price_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_price_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['orignal_price_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['orignal_price_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Original Price Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_dicount_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_dicount_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['discount_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_dicount_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_dicount_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['discount_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Discount Background Color</p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_discount_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_discount_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['discount_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_discount_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_discount_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['discount_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Discount Text Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_atc_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_atc_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_atc_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_atc_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Button Background Color</p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_btn_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_btn_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_btn_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_border_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Button Border Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Button Text Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3 class="mt-4">Translation</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Checkout Button</label><br>
                                       <input type="text" name="alpha_t6_checkout_btn" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_checkout_btn']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_button_text']); ?>"
                                          <?php endif; ?> 
                                       >
                                    </p>
                                    <p class="f_input">
                                       <label>No Thanks Button</label><br>
                                       <input type="text" name="alpha_no_thanks_btn" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_no_thanks_btn']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_button_text']); ?>"
                                          <?php endif; ?> 
                                       />
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_checkout_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_checkout_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_checkout_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_checkout_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_no_thanks_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_no_thanks_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_no_thanks_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_no_thanks_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_background_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_checkout_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_checkout_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_checkout_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_checkout_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Text Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_no_thanks_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_no_thanks_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_no_thanks_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_no_thanks_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_text_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Text Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t6_checkout_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t6_checkout_btn_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t6_checkout_btn_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t6_checkout_btn_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_border_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Checkout Border Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_no_thanks_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_no_thanks_btn_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_no_thanks_btn_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_no_thanks_btn_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_border_color']); ?>" 
                                          <?php endif; ?>
                                        />
                                       <p>No,Thanks Border Color </p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="design_p_inpage pt-2">
                              <!-------Modal content------->
                              <div class="modal-content modal_5 alpha_atc_t_6">
                                 <div class="modal_5_head">
                                    <h2 class="alpha_t6_top_heading">
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             <?php echo e($upsell->setting['alpha_t6_top_heading']); ?>   
                                          <?php else: ?>    
                                             <?php echo e($setting['top_heading']); ?>

                                          <?php endif; ?>
                                       <?php else: ?>
                                          <?php echo e($setting['top_heading']); ?>

                                       <?php endif; ?> 
                                    </h2>
                                    <span class="close t6_cross_icon" id="myModal5">×</span>
                                 </div>
                                 <div class="modal_5_body">
                                    <div class="m5_products">
                                       <div class="m5_item">
                                          <h3 class="alpha_t6_cart_product_heading" style="margin: 15px !important;"></h3>
                                          <div class="prodcut_item">
                                             <div class="item_img">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-10-1.png" alt="bag">
                                             </div>
                                             <div class="item_detail">
                                                <h4>Ladies Trending Leather Hand Bag</h4>
                                                <p class="t6_cart_product_price"><?php echo e($currency); ?>24.95</p>
                                                <input type="button" class="alpha_t6_checkout_btn" value=
                                                   <?php if(isset($upsell)): ?>
                                                      <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                         "<?php echo e($upsell->setting['alpha_t6_checkout_btn']); ?>"   
                                                      <?php else: ?>    
                                                         "<?php echo e($setting['checkout_button_text']); ?>"
                                                      <?php endif; ?>
                                                   <?php else: ?>
                                                      "<?php echo e($setting['checkout_button_text']); ?>"
                                                   <?php endif; ?> 
                                                >
                                             </div>
                                          </div>
                                       </div>
                                       <div class="m5_p">
                                          <h3 class="alpha_t6_product_heading">
                                             <?php if(isset($upsell)): ?>
                                                <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                   <?php echo e($upsell->setting['alpha_t6_product_heading']); ?>   
                                                <?php else: ?>    
                                                   <?php echo e($setting['offer_heading']); ?>

                                                <?php endif; ?>
                                             <?php else: ?>
                                                <?php echo e($setting['offer_heading']); ?>

                                             <?php endif; ?>
                                          </h3>
                                          <div class="sale_item">
                                             <div class="sale_img">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-10-2.webp" alt="bag">
                                             </div>
                                             <div class="sale_detail">
                                                <h4>Ladies Trending Leather Hand Bag</h4>
                                                <p><?php echo e($currency); ?>34.95 <span>10%Off</span></p>
                                                <select>
                                                   <option>Sky Blue</option>
                                                   <option>Red</option>
                                                   <option>Green</option>
                                                </select>
                                                <select>
                                                   <option>M</option>
                                                   <option>S</option>
                                                   <option>L</option>
                                                </select>
                                                <input type="button" class="alpha_t6_atc_btn" value=
                                                   <?php if(isset($upsell)): ?>
                                                      <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                         "<?php echo e($upsell->setting['alpha_t6_cart_btn']); ?>"   
                                                      <?php else: ?>    
                                                         "<?php echo e($setting['add_to_cart_text']); ?>"
                                                      <?php endif; ?>
                                                   <?php else: ?>
                                                      "<?php echo e($setting['add_to_cart_text']); ?>"
                                                   <?php endif; ?>
                                                >
                                             </div>
                                          </div>
                                          <div class="sale_item">
                                             <div class="sale_img">
                                                <img src="<?php echo e(asset('assets')); ?>/img/m-10-3.jpg" alt="bag">
                                             </div>
                                             <div class="sale_detail">
                                                <h4>Ladies Trending Leather Hand Bag</h4>
                                                <p><?php echo e($currency); ?>24.95 <span>10%Off</span></p>
                                                <select>
                                                   <option>Blue</option>
                                                   <option>Red</option>
                                                   <option>Green</option>
                                                </select>
                                                <select>
                                                   <option>M</option>
                                                   <option>S</option>
                                                   <option>L</option>
                                                </select>
                                                <input type="button" class="alpha_t6_atc_btn" value=
                                                   <?php if(isset($upsell)): ?>
                                                      <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                         "<?php echo e($upsell->setting['alpha_t6_cart_btn']); ?>"   
                                                      <?php else: ?>    
                                                         "<?php echo e($setting['add_to_cart_text']); ?>"
                                                      <?php endif; ?>
                                                   <?php else: ?>
                                                      "<?php echo e($setting['add_to_cart_text']); ?>"
                                                   <?php endif; ?>
                                                >
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="m5_footer">
                                    <input type="button" class="m5_thanks" value=
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             "<?php echo e($upsell->setting['alpha_no_thanks_btn']); ?>"   
                                          <?php else: ?>    
                                             "<?php echo e($setting['no_thanks_button_text']); ?>"
                                          <?php endif; ?>
                                       <?php else: ?>
                                          "<?php echo e($setting['no_thanks_button_text']); ?>"
                                       <?php endif; ?> 
                                    >
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="cancel" data-dismiss="modal">Cancel</button>
               <?php if(isset($upsell)): ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save update_setting">Save Changes</button>
               <?php else: ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save save_setting">Save Changes</button>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </form>
</div><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/includes/components/add_to_cart_template6.blade.php ENDPATH**/ ?>