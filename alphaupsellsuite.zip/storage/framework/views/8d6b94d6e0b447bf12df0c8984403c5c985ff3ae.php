<!-----------Modal-2---------->
<div class="modal fade" id="centralModalSm2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
   aria-hidden="true">
   <!-- Change class .modal-sm to change the size of the modal -->
   <form class="template-<?php echo e($upsellTemplateId); ?>">
      <div class="modal-dialog modal-sm m_1_w" role="document">
         <div class="modal-content modal_1_show" style="height: 100vh !important;">
            <div class="modal-header">
               <h4 class="modal-title w-100 m_head_h">Customize Your Template</h4>
               <button type="button" class="close m1_close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
               </button>
            </div>
            <div class="modal-body m_1_body">
               <div class="container">
                  <div class="col-md-12 popup_page">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="design_input">
                              <h3>Title</h3>
                              <p class="h_input">
                                 <label>Heading</label><br>
                                 <input type="text" value=
                                    <?php if(isset($upsell)): ?>
                                       "<?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_atc_t1_heading'] : $setting['top_heading']); ?>"
                                    <?php else: ?>
                                       "<?php echo e($setting['top_heading']); ?>"
                                    <?php endif; ?>
                                  placeholder="You Just Added" name="alpha_atc_t1_heading">    
                              </p>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Font family</label><br>
                                       <select name="alpha_t2_heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>" 
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['alpha_t2_heading_font_family']  == $family ? "selected":""); ?>   
                                                   <?php else: ?>    
                                                       <?php echo e($setting['top_heading_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($setting['top_heading_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?> 
                                            >
                                                   <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Font Size</label><br>
                                       <input type="number" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_heading_font_size']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['top_heading_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['top_heading_font_size']); ?>"
                                          <?php endif; ?> 
                                       name="alpha_t2_heading_font_size" >    
                                    </p>
                                    <p class="f_input">
                                 <label>Total Price </label><br>
                                 <input type="text" name="t2-total-price-text" value=
                                 <?php if(isset($upsell)): ?>
                                    <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                       "<?php echo e($upsell->setting['t2-total-price-text']); ?>"   
                                    <?php else: ?>    
                                       "<?php echo e($setting['t2-total-price-text']); ?>"
                                    <?php endif; ?>
                                 <?php else: ?>
                                    "<?php echo e($setting['t2-total-price-text']); ?>"
                                 <?php endif; ?>
                                 />    
                                 </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_heading_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['top_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['top_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       ></a>
                                       <input type="hidden" name="alpha_t2_heading_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_heading_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['top_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['top_heading_color']); ?>" 
                                          <?php endif; ?>
                                        />
                                       <p>Heading Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_heading_background" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_heading_background']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['top_heading_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['top_heading_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_heading_background" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_heading_background']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['top_heading_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['top_heading_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_icon_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_icon_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cross_icon_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_color']); ?>;" 
                                          <?php endif; ?>
                                       >    
                                       </a>
                                       <input type="hidden" name="alpha_t2_icon_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_icon_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cross_icon_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Icon Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_icon_background" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_icon_background']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['cross_icon_bg_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['cross_icon_bg_color']); ?>;" 
                                          <?php endif; ?>
                                       > 
                                       </a>
                                       <input type="hidden" name="alpha_t2_icon_background" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_icon_background']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['cross_icon_bg_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['cross_icon_bg_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Icon Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                 
                                    <div class="f_input_color">
                                       <a href="#" data-id="t2-total-price-color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['t2-total-price-color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['t2-total-price-color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['t2-total-price-color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="t2-total-price-color" value=
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             "<?php echo e($upsell->setting['t2-total-price-color']); ?>"    
                                          <?php else: ?>    
                                             "<?php echo e($setting['t2-total-price-color']); ?>"
                                          <?php endif; ?>
                                       <?php else: ?>
                                          "<?php echo e($setting['t2-total-price-color']); ?>" 
                                       <?php endif; ?>
                                       />
                                       <p> Total Price Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="t2-price-color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['t2-price-color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['t2-price-color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['t2-price-color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="t2-price-color" value=
                                       <?php if(isset($upsell)): ?>
                                          <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                             "<?php echo e($upsell->setting['t2-price-color']); ?>"    
                                          <?php else: ?>    
                                             "<?php echo e($setting['t2-price-color']); ?>"
                                          <?php endif; ?>
                                       <?php else: ?>
                                          "<?php echo e($setting['t2-price-color']); ?>" 
                                       <?php endif; ?>
                                       />
                                       <p> Price Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Countdown Sales Timer</h3>
                              <div class="custom-control custom-checkbox">
                                 <input type="checkbox" value="1" class="custom-control-input" name="alpha_t2_timer_limit" id="alpha_t2_timer_limit" 
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          <?php echo e($upsell->setting['alpha_t2_timer_limit'] ? "checked" : ""); ?>

                                       <?php else: ?>    
                                          <?php echo e($setting['offer_time_limit'] ? "checked":""); ?>

                                       <?php endif; ?>
                                    <?php else: ?>
                                       <?php echo e($setting['offer_time_limit'] ? "checked":""); ?>

                                    <?php endif; ?>
                                 >
                                 <label class="custom-control-label" for="alpha_t2_timer_limit">Add a Time Limit To The Offer</label>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Heading</label><br>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_deal_heading']); ?>"    
                                             <?php else: ?>    
                                               "<?php echo e($setting['offer_heading']); ?>" 
                                             <?php endif; ?>
                                          <?php else: ?>
                                         "<?php echo e($setting['offer_heading']); ?>" 
                                          <?php endif; ?>
                                       name="alpha_t2_deal_heading">    
                                    </p>
                                    <p class="f_input">
                                       <label>Span</label><br>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_deal_span']); ?>"    
                                             <?php else: ?>    
                                              "<?php echo e($setting['offer_span']); ?>" 
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['offer_span']); ?>" 
                                          <?php endif; ?>
                                       name="alpha_t2_deal_span">    	  
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Heading Font family</label><br>
                                       <select name="t2_heading_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>"
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['t2_heading_font_family']  == $family ? "selected":""); ?>   
                                                   <?php else: ?>    
                                                      <?php echo e($setting['offer_heading_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($setting['offer_heading_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?>
                                              >
                                                   <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Heading Font Size</label><br>
                                       <input type="number" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['t2_heading_font_size']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['offer_heading_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['offer_heading_font_size']); ?>"
                                          <?php endif; ?> 
                                       name="t2_heading_font_size">    
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Timer Duration In Minutes</label><br>
                                       <input type="number" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['t2_time_duration']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['time_duration_minutes']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_duration_minutes']); ?>"
                                          <?php endif; ?>
                                       name="t2_time_duration">    
                                    </p>
                                    <p class="f_input">
                                       <label>Timer Text</label><br>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['t2_timer_text']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['time_offer_heading']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['time_offer_heading']); ?>"
                                          <?php endif; ?> 
                                       name="t2_timer_text">    	  
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Font family</label><br>
                                       <select name="t2_timer_text_font_family">
                                          <?php $__currentLoopData = config('upsell.strings.fontFamily'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($family); ?>" 
                                                <?php if(isset($upsell)): ?>
                                                   <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                      <?php echo e($upsell->setting['t2_timer_text_font_family']  == $family ? "selected":""); ?>   
                                                   <?php else: ?>    
                                                      <?php echo e($setting['timer_heading_font_family'] == $family ? "selected":""); ?>

                                                   <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($setting['timer_heading_font_family'] == $family ? "selected":""); ?>

                                                <?php endif; ?>
                                             >
                                                <?php echo e($family); ?>

                                             </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       </select>
                                    </p>
                                    <p class="f_input">
                                       <label>Font Size</label><br>
                                       <input type="number" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['t2_timer_text_font_size']); ?>"   
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_heading_font_size']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_heading_font_size']); ?>"
                                          <?php endif; ?>
                                       name="t2_timer_text_font_size">    
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_deal_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_deal_heading_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['offer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['offer_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       > 
                                       </a>
                                       <input type="hidden" name="alpha_t2_deal_heading_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_deal_heading_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['offer_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['offer_heading_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Heading Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_deal_span_color"  class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_deal_span_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['offer_span_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['offer_span_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_deal_span_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_deal_span_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['offer_span_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['offer_span_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Span Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="t2_timer_heading_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['t2_timer_heading_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_heading_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_heading_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="t2_timer_heading_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['t2_timer_heading_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_heading_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_heading_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>Timer Heading Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="t2_timer_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['t2_timer_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['timer_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['timer_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="t2_timer_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['t2_timer_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['timer_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['timer_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['timer_color']); ?>" />
                                       <p>Timer Color </p>
                                    </div>
                                 </div>
                              </div>
                              <h3>Product</h3>
                              <p class="h_input">
                                 <label>Button Text</label><br>
                                 <input type="text" value=
                                    <?php if(isset($upsell)): ?>
                                       <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                          "<?php echo e($upsell->setting['alpha_t2_atc_btn_text']); ?>;"    
                                       <?php else: ?>    
                                          "<?php echo e($setting['add_to_cart_text']); ?>"
                                       <?php endif; ?>
                                    <?php else: ?>
                                       "<?php echo e($setting['add_to_cart_text']); ?>" 
                                    <?php endif; ?>
                                 placeholder="Add To Cart" name="alpha_t2_atc_btn_text">    
                              </p>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_atc_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_atc_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_atc_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_atc_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_background_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['atc_background_color']); ?>" />
                                       <p>Button Background Color</p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_atc_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_atc_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['atc_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['atc_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_atc_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_atc_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['atc_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['atc_text_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['atc_text_color']); ?>" />
                                       <p>Button Text Color</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_price_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_price_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['Original_price_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['Original_price_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_price_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_price_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['Original_price_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['Original_price_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['Original_price_color']); ?>" />
                                       <p>Original Price Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_discount_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_discount_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['discount_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_discount_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_discount_bg_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['discount_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_background_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['discount_background_color']); ?>" />
                                       <p>Discount Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_discount_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_discount_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['discount_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['discount_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_discount_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_discount_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['discount_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['discount_text_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['discount_text_color']); ?>" />
                                       <p>Discount Text Color</p>
                                    </div>
                                 </div>
                              </div>
                              <h3 class="mt-4">Translation</h3>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <p class="f_input">
                                       <label>Checkout Button</label><br>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_checkout_btn']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['checkout_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['checkout_button_text']); ?>"
                                          <?php endif; ?> 
                                       placeholder="Checkout" name="alpha_t2_checkout_btn">    
                                    </p>
                                    <p class="f_input">
                                       <label>No Thanks Button</label><br>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_no_thanks_btn']); ?>"   
                                             <?php else: ?>    
                                               "<?php echo e($setting['no_thanks_button_text']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['no_thanks_button_text']); ?>"
                                          <?php endif; ?>
                                       placeholder="No Thanks" name="alpha_t2_no_thanks_btn">    	  
                                    </p>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_checkout_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_checkout_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                                 "background-color:<?php echo e($setting['checkout_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                              "background-color:<?php echo e($setting['checkout_background_color']); ?>;" 
                                          <?php endif; ?>
                                      >
                                       </a>
                                       <input type="hidden" name="alpha_t2_checkout_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_checkout_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                                 "<?php echo e($setting['checkout_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                              "<?php echo e($setting['checkout_background_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['checkout_background_color']); ?>" />
                                       <p>Checkout Background Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_no_thanks_btn_bg_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_no_thanks_btn_bg_color']); ?>;"    
                                             <?php else: ?>    
                                               "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "background-color:<?php echo e($setting['no_thanks_background_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_no_thanks_btn_bg_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_no_thanks_btn_bg_color']); ?>"    
                                             <?php else: ?>    
                                               "<?php echo e($setting['no_thanks_background_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                            "<?php echo e($setting['no_thanks_background_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['no_thanks_background_color']); ?>" />
                                       <p>No,Thanks Background Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_checkout_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_checkout_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_checkout_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_checkout_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_text_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['checkout_text_color']); ?>" />
                                       <p>Checkout Text Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_no_thanks_btn_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_no_thanks_btn_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_text_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_no_thanks_btn_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_no_thanks_btn_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_text_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_text_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['no_thanks_text_color']); ?>" />
                                       <p>No,Thanks Text Color </p>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-12 font">
                                 <div class="row">
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_checkout_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_checkout_btn_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['checkout_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['checkout_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden" name="alpha_t2_checkout_btn_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_checkout_btn_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['checkout_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['checkout_border_color']); ?>" 
                                          <?php endif; ?>
                                       "<?php echo e($setting['checkout_border_color']); ?>" />
                                       <p>Checkout Border Color </p>
                                    </div>
                                    <div class="f_input_color">
                                       <a href="#" data-id="alpha_t2_no_thanks_btn_border_color" class="buttoncolor colorpicker" id="basic" style=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "background-color:<?php echo e($upsell->setting['alpha_t2_no_thanks_btn_border_color']); ?>;"    
                                             <?php else: ?>    
                                                "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "background-color:<?php echo e($setting['no_thanks_border_color']); ?>;" 
                                          <?php endif; ?>
                                       >
                                       </a>
                                       <input type="hidden"  name="alpha_t2_no_thanks_btn_border_color" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php if($upsell->setting['upsell_template_type'] == $upsellTemplateId): ?>
                                                "<?php echo e($upsell->setting['alpha_t2_no_thanks_btn_border_color']); ?>"    
                                             <?php else: ?>    
                                                "<?php echo e($setting['no_thanks_border_color']); ?>"
                                             <?php endif; ?>
                                          <?php else: ?>
                                             "<?php echo e($setting['no_thanks_border_color']); ?>" 
                                          <?php endif; ?>
                                       />
                                       <p>No,Thanks Border Color </p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="design_p_inpage pt-2">
                              <!-------Modal content------->
                              <div class="modal_6 alpha_atc_t_2">
                                 <div class="modal_6_head">
                                    <h2>
                                       <i class="fa fa-check t1_icon"></i>
                                       <span class="alpha_t2_heading">
                                          <?php if(isset($upsell)): ?>
                                             <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_atc_t1_heading'] : $setting['top_heading']); ?>

                                          <?php else: ?>
                                             <?php echo e($setting['top_heading']); ?>

                                          <?php endif; ?>
                                       </span> 
                                       <span class="close c6" id="myModal6">
                                       <i class="fa fa-times t1_icon"></i>
                                       </span>
                                    </h2>
                                    <div class="head_item">
                                       <div class="h_item_img">
                                          <img src="<?php echo e(asset('assets')); ?>/img/m-6-1.jpg" alt="dress">
                                       </div>
                                       <div class="h_item_heading">
                                          <h3>Shop Ethnic Outfits Online - Affordable<br> Women's Clothes..!!</h3>
                                       </div>
                                       <div class="h_item_btn" style="text-align: center !important;">
                                          <div class="price-div" style="display: flex; justify-content: center;">
                                          <p class="total-price-t2">Total:</p>
                                          <p><span class="price-fig-t2"><?php echo e($currency); ?>29.95</span></p>
                                          </div>
                                          <button type="button" class="h_item_btnstyle alpha_t2_checkout_button">
                                             <?php if(isset($upsell)): ?>
                                                <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t2_checkout_btn'] : $setting['checkout_button_text']); ?>

                                             <?php else: ?>
                                                <?php echo e($setting['checkout_button_text']); ?>

                                             <?php endif; ?>
                                          </button>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="m6_timer">
                                    <h2> 
                                       <p class="t2_deal_heading temp_2_deal_heading">                                    
                                          <?php if(isset($upsell)): ?>
                                             <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t2_deal_heading'] : $setting['offer_heading']); ?>

                                          <?php else: ?>
                                             <?php echo e($setting['offer_heading']); ?>

                                          <?php endif; ?>
                                       </p> 
                                       <span class="t2_deal_discount temp_2_deal_heading">
                                          <?php if(isset($upsell)): ?>
                                             <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t2_deal_span'] : $setting['offer_span']); ?>

                                          <?php else: ?>
                                             <?php echo e($setting['offer_span']); ?>

                                          <?php endif; ?>
                                       </span>
                                    </h2>
                                    <div class="m_3_time">
                                       <label class="t2_timer_text">
                                          <?php if(isset($upsell)): ?>
                                             <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['t2_timer_text'] : $setting['time_offer_heading']); ?>

                                          <?php else: ?>
                                             <?php echo e($setting['time_offer_heading']); ?>

                                          <?php endif; ?>
                                       </label>
                                       <input type="text" value=
                                          <?php if(isset($upsell)): ?>
                                             <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['t2_time_duration'] : $setting['time_duration_minutes']); ?>

                                          <?php else: ?>
                                             <?php echo e($setting['time_duration_minutes']); ?>

                                          <?php endif; ?>
                                       class="t2_time_duration t2_timer" readonly>:<input class="t2_timer" type="text" value="00" readonly>
                                    </div>
                                 </div>
                                 <div class="modal_6_body">
                                    <div class="m6_products">
                                       <div class="m6_p_img">
                                          <img src="<?php echo e(asset('assets')); ?>/img/m-6-2.jpg" alt="bag"> 
                                       </div>
                                       <div class="m6_p_heading">
                                          <h2>Women's handbag Female leather shoulder bag..!! <span>
                                             <button type="button" class="h_item_btnstyle alpha_t2_atc_btn">
                                                <?php if(isset($upsell)): ?>
                                                   <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t2_atc_btn_text'] : $setting['add_to_cart_text']); ?>

                                                <?php else: ?>
                                                   <?php echo e($setting['add_to_cart_text']); ?>

                                                <?php endif; ?>
                                             </button></span>
                                          </h2>
                                          <p><?php echo e($currency); ?>29.99 <span>10%Off</span></p>
                                          <select>
                                             <option>Black</option>
                                             <option>Blue</option>
                                             <option>Red</option>
                                          </select>
                                       </div>
                                    </div>
                                    <div class="m6_products">
                                       <div class="m6_p_img">
                                          <img src="<?php echo e(asset('assets')); ?>/img/m-6-4.jpg" alt="bag"> 
                                       </div>
                                       <div class="m6_p_heading">
                                          <h2>Women's Shoes Female Heels Yellow Shoes.!! <span>
                                             <button type="button" class="h_item_btnstyle alpha_t2_atc_btn">
                                                <?php if(isset($upsell)): ?>
                                                   <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t2_atc_btn_text'] : $setting['add_to_cart_text']); ?>

                                                <?php else: ?>
                                                   <?php echo e($setting['add_to_cart_text']); ?>

                                                <?php endif; ?>
                                             </button></span>
                                          </h2>
                                          <p><?php echo e($currency); ?>29.99 <span>10%Off</span></p>
                                          <select>
                                             <option>Yellow</option>
                                             <option>Blue</option>
                                             <option>Red</option>
                                          </select>
                                          <select>
                                             <option>24</option>
                                             <option>26</option>
                                             <option>28</option>
                                          </select>
                                       </div>
                                    </div>
                                    <div class="m6_products">
                                       <div class="m6_p_img">
                                          <img src="<?php echo e(asset('assets')); ?>/img/m-6-3.jpg" alt="bag"> 
                                       </div>
                                       <div class="m6_p_heading">
                                          <h2>Women's handbag Female leather shoulder bag..!! <span>
                                             <button type="button" class="h_item_btnstyle alpha_t2_atc_btn">
                                                <?php if(isset($upsell)): ?>
                                                   <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t2_atc_btn_text'] : $setting['add_to_cart_text']); ?>

                                                <?php else: ?>
                                                   <?php echo e($setting['add_to_cart_text']); ?>

                                                <?php endif; ?>
                                             </button></span>
                                          </h2>
                                          <p><?php echo e($currency); ?>29.99 <span>10%Off</span></p>
                                          <select>
                                             <option>Gray</option>
                                             <option>Blue</option>
                                             <option>Red</option>
                                          </select>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="modal_6_footer">
                                    <button type="button" class="no_thanks_btn">
                                       <?php if(isset($upsell)): ?>
                                          <?php echo e($upsell->setting['upsell_template_type'] == $upsellTemplateId ? $upsell->setting['alpha_t2_no_thanks_btn'] : $setting['no_thanks_button_text']); ?>

                                       <?php else: ?>
                                          <?php echo e($setting['no_thanks_button_text']); ?>

                                       <?php endif; ?>
                                    </button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="cancel" data-dismiss="modal">Cancel</button>
               <?php if(isset($upsell)): ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save update_setting">Save changes</button>
               <?php else: ?>
                  <button type="button" data-id="<?php echo e($upsellTemplateId); ?>" class="save save_setting">Save changes</button>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </form>
</div>
<!--------Modal-2-close-------><?php /**PATH /www/wwwroot/app.alphaupsellsuite.com/resources/views/includes/components/add_to_cart_template2.blade.php ENDPATH**/ ?>