<?php
return [
    'createUpsellForm' => [
        'name'      => [ 'required', 'string', 'max:191' ]
    ],
    'saleNotification' => [

    ]
];